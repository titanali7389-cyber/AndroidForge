package ir.hours77

/** وضعیت قابل ذخیره‌ی بازی */
class GameState {
    var main = 0            // مرحله‌ی مأموریت اصلی
    var money = 0
    var kind = 0            // امتیاز مهربانی (روی پایان اثر می‌گذارد)
    var outfit = 0
    var minutes = 0f
    var px = 380f
    var py = 370f
    var scene = 0           // -1 = بیرون، ۰ تا ۳ = داخل ساختمان‌ها
    val flags = HashSet<String>()
    val owned = HashSet<Int>()
    val inv = HashMap<String, Int>()

    init { owned.add(0) }

    fun has(f: String): Boolean = flags.contains(f)
    fun set(f: String) { flags.add(f) }
    fun n(k: String): Int = inv[k] ?: 0
    fun add(k: String, v: Int) {
        val nv = (inv[k] ?: 0) + v
        if (nv <= 0) inv.remove(k) else inv[k] = nv
    }

    fun encode(): String {
        val invS = inv.entries.joinToString(",") { it.key + ":" + it.value }
        return listOf(
            main, money, kind, outfit, minutes, px, py, scene,
            flags.joinToString(","), owned.joinToString(","), invS
        ).joinToString("|")
    }

    companion object {
        fun decode(s: String?): GameState? {
            if (s == null) return null
            return try {
                val p = s.split("|")
                if (p.size < 11) return null
                val g = GameState()
                g.main = p[0].toInt(); g.money = p[1].toInt(); g.kind = p[2].toInt()
                g.outfit = p[3].toInt(); g.minutes = p[4].toFloat()
                g.px = p[5].toFloat(); g.py = p[6].toFloat(); g.scene = p[7].toInt()
                p[8].split(",").filter { it.isNotBlank() }.forEach { g.flags.add(it) }
                p[9].split(",").filter { it.isNotBlank() }.forEach { g.owned.add(it.toInt()) }
                p[10].split(",").filter { it.contains(":") }.forEach {
                    val kv = it.split(":")
                    g.inv[kv[0]] = kv[1].toInt()
                }
                g
            } catch (e: Exception) {
                null
            }
        }
    }
}
