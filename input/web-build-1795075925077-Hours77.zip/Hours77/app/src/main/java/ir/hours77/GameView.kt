package ir.hours77

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import java.util.Locale
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * موتور بازی «۷۷ ساعت» (۲بعدی از بالا).
 * محله‌ی گلستان (بازسازی خیالی) + داخل ساختمان‌ها + مأموریت + دیالوگ با انتخاب
 * + فروشگاه + لباس + ذخیره + مینی‌مپ + شب و روز + باران + ترافیک + صدا.
 */
class GameView(
    ctx: Context,
    private val slot: Int,
    newGame: Boolean,
    private val onExit: () -> Unit
) : View(ctx) {

    // ---------------- مدل‌ها ----------------
    private class Bld(val r: RectF, val kind: Int, val color: Int, val sign: String?, val seed: Int)
    private class Npc(val id: String, val name: L, val x: Float, val y: Float, val scene: Int, val body: Int, val hair: Int)
    private class Car(var pos: Float, val lane: Float, val speed: Float, val color: Int, val horizontal: Boolean)
    private class Sign(val x: Float, val y: Float, val text: String)
    private class Door(val x: Float, val y: Float, val room: Int, val label: L)
    private class Obj(val id: String, val x: Float, val y: Float, val kind: Int)
    private class Furn(val r: RectF, val color: Int, val label: L?, val solid: Boolean)
    private class Room(
        val name: L, val w: Float, val h: Float, val floor: Int,
        val furn: List<Furn>, val spawnX: Float, val spawnY: Float, val exit: RectF
    )
    private class Btn(val r: RectF, val act: () -> Unit)

    // ---------------- دنیا ----------------
    private val WW = 2400f
    private val WH = 1600f
    private val buildings = ArrayList<Bld>()
    private val npcs = ArrayList<Npc>()
    private val cars = ArrayList<Car>()
    private val signs = ArrayList<Sign>()
    private val palms = ArrayList<FloatArray>()
    private val doors = ArrayList<Door>()
    private val objs = ArrayList<Obj>()
    private val rooms = ArrayList<Room>()
    private val park = RectF(1330f, 1260f, 1940f, 1520f)

    private val d = resources.displayMetrics.density
    private val zoom = d * 0.85f

    private val outfitColors = intArrayOf(
        Color.parseColor("#2F6DB5"), Color.parseColor("#FF7A1A"),
        Color.parseColor("#1C1C1E"), Color.parseColor("#3E7A3A")
    )

    // ---------------- وضعیت ----------------
    private var s: GameState = GameState()
    private var px: Float
        get() = s.px
        set(v) { s.px = v }
    private var py: Float
        get() = s.py
        set(v) { s.py = v }
    private var fx = 0f
    private var fy = 1f
    private var running = false
    private var moving = false
    private var walkPhase = 0f
    private var stepAcc = 0f
    private var anim = 0f
    private var paused = false
    private var pauseMode = 0           // 0 اصلی، 1 مأموریت‌ها، 2 کوله‌پشتی
    private var shopId: String? = null
    private var toast: String? = null
    private var toastT = 0f

    // دیالوگ
    private var cur: List<Node>? = null
    private var dIdx = 0
    private var dLayout: StaticLayout? = null
    private var dLayoutNode: Node? = null
    private var dLayoutW = 0

    // ورودی
    private var joyId = -1
    private var joyCx = 0f
    private var joyCy = 0f
    private var joyDx = 0f
    private var joyDy = 0f
    private val joyR = 60f * d
    private var kL = false
    private var kR = false
    private var kU = false
    private var kD = false
    private val btnInteract = floatArrayOf(0f, 0f, 44f * d)
    private val btnRun = floatArrayOf(0f, 0f, 32f * d)
    private val btnPause = floatArrayOf(0f, 0f, 24f * d)
    private val btns = ArrayList<Btn>()

    // رسم
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val tmp = RectF()
    private val view = RectF()
    private var vignette: Paint? = null
    private val rainX = FloatArray(140) { Random.nextFloat() }
    private val rainY = FloatArray(140) { Random.nextFloat() }
    private val dustX = FloatArray(40) { Random.nextFloat() }
    private val dustY = FloatArray(40) { Random.nextFloat() }

    // حلقه‌ی بازی
    private val handler = Handler(Looper.getMainLooper())
    private var last = 0L
    private val tick = object : Runnable {
        override fun run() {
            val start = System.nanoTime()
            val dt = min(0.05f, (start - last) / 1e9f)
            last = start
            update(dt)
            invalidate()
            val frameMs = 1000L / Prefs.fps(context)
            val spent = (System.nanoTime() - start) / 1_000_000L
            handler.postDelayed(this, max(1L, frameMs - spent))
        }
    }

    init {
        isFocusable = true
        isFocusableInTouchMode = true
        buildWorld()
        buildRooms()
        val loaded = if (newGame) null else GameState.decode(Prefs.slotData(ctx, slot))
        if (loaded != null) {
            s = loaded
        } else {
            s = GameState()
            s.scene = 0
            s.px = rooms[0].spawnX; s.py = rooms[0].spawnY
            cur = Story.intro(); dIdx = 0
        }
        Sound.setScene(s.scene < 0)
    }

    private fun col(x: String) = Color.parseColor(x)

    // =====================================================================
    //  ساخت دنیا
    // =====================================================================
    private fun addB(x: Float, y: Float, w: Float, h: Float, kind: Int, color: String, sign: String? = null) {
        buildings.add(Bld(RectF(x, y, x + w, y + h), kind, col(color), sign, buildings.size * 13 + 5))
    }

    private fun buildWorld() {
        val brick = "#B5835A"; val sand = "#C9AE85"; val cream = "#D9C9A3"; val clay = "#A8734E"; val grey = "#9A978F"
        // شمال غربی
        addB(650f, 400f, 320f, 240f, 2, cream)
        addB(60f, 380f, 260f, 260f, 0, brick)
        addB(360f, 420f, 240f, 220f, 0, sand)
        addB(60f, 60f, 300f, 240f, 0, clay)
        addB(400f, 80f, 260f, 250f, 0, grey)
        addB(720f, 80f, 280f, 240f, 0, brick)
        // شمال شرقی
        addB(1330f, 440f, 260f, 200f, 1, "#8FAE9B", "نانوایی")
        addB(1640f, 440f, 240f, 200f, 1, "#C9A06B", "بقالی")
        addB(1930f, 400f, 300f, 240f, 0, brick)
        addB(1330f, 80f, 300f, 260f, 0, sand)
        addB(1680f, 80f, 260f, 260f, 0, clay)
        addB(1980f, 60f, 340f, 260f, 0, grey)
        // جنوب غربی
        addB(760f, 960f, 280f, 220f, 1, "#E6E6DC", "داروخانه")
        addB(60f, 980f, 260f, 260f, 0, sand)
        addB(360f, 1000f, 300f, 220f, 0, brick)
        addB(60f, 1300f, 300f, 240f, 0, grey)
        addB(400f, 1280f, 260f, 260f, 0, clay)
        addB(760f, 1260f, 280f, 260f, 0, cream)
        // جنوب شرقی (پارک بین ساختمان‌ها)
        addB(1330f, 960f, 260f, 200f, 1, "#B9D07A", "میوه‌فروشی")
        addB(1640f, 980f, 260f, 240f, 0, brick)
        addB(1950f, 960f, 330f, 260f, 0, sand)
        addB(1980f, 1300f, 340f, 240f, 0, clay)

        npcs.add(Npc("gran", L("مادربزرگ", "Grandma"), 600f, 150f, 0, col("#7A4E8C"), col("#CFCFCF")))
        npcs.add(Npc("baker", L("کریم", "Karim"), 380f, 130f, 1, col("#E0A33A"), col("#2A2A2A")))
        npcs.add(Npc("pharm", L("دکتر نیلوفر", "Dr. Niloufar"), 380f, 130f, 2, col("#3C8D7B"), col("#1E1E1E")))
        npcs.add(Npc("groc", L("آقا بهروز", "Mr. Behrouz"), 380f, 130f, 3, col("#8A6E4B"), col("#555555")))
        npcs.add(Npc("sara", L("سارا", "Sara"), 1080f, 300f, -1, col("#B04A6B"), col("#2A1A14")))
        npcs.add(Npc("jalal", L("عمو جلال", "Uncle Jalal"), 1500f, 925f, -1, col("#6E8F4B"), col("#8A8A8A")))
        npcs.add(Npc("amir", L("امیر", "Amir"), 1500f, 1225f, -1, col("#4B8FB0"), col("#3A2A1A")))
        npcs.add(Npc("cloth", L("فروشنده", "Vendor"), 2150f, 925f, -1, col("#A04B4B"), col("#2A2A2A")))

        doors.add(Door(750f, 662f, 0, L("خانه", "Home")))
        doors.add(Door(1460f, 662f, 1, L("نانوایی", "Bakery")))
        doors.add(Door(1760f, 662f, 3, L("بقالی", "Grocery")))
        doors.add(Door(900f, 938f, 2, L("داروخانه", "Pharmacy")))

        objs.add(Obj("crate_1", 1085f, 160f, 0))
        objs.add(Obj("crate_2", 1275f, 1450f, 0))
        objs.add(Obj("crate_3", 560f, 950f, 0))
        objs.add(Obj("cat", 1600f, 1400f, 1))

        cars.add(Car(200f, 750f, 140f, col("#D9D9D9"), true))
        cars.add(Car(1300f, 750f, 170f, col("#C9A227"), true))
        cars.add(Car(900f, 850f, -150f, col("#6E8FB3"), true))
        cars.add(Car(1900f, 850f, -120f, col("#B04A3F"), true))
        cars.add(Car(300f, 1150f, 130f, col("#D9D9D9"), false))
        cars.add(Car(1200f, 1210f, -140f, col("#4E5D6A"), false))

        signs.add(Sign(300f, 668f, "خیابان اصلی"))
        signs.add(Sign(1180f, 578f, "محله‌ی گلستان"))
        signs.add(Sign(2100f, 668f, "خیابان اصلی"))
        signs.add(Sign(1180f, 1350f, "کوچه‌ی گلستان"))

        for (x in floatArrayOf(120f, 520f, 1020f, 1400f, 1800f, 2200f)) palms.add(floatArrayOf(x, 682f))
        for (x in floatArrayOf(240f, 680f, 1100f, 1500f, 2000f)) palms.add(floatArrayOf(x, 920f))
        for (x in floatArrayOf(1400f, 1560f, 1720f, 1860f)) palms.add(floatArrayOf(x, 1300f))
        for (x in floatArrayOf(1420f, 1700f)) palms.add(floatArrayOf(x, 1480f))
    }

    private fun f(l: Float, t: Float, r: Float, b: Float, color: String, label: L?, solid: Boolean = true) =
        Furn(RectF(l, t, r, b), col(color), label, solid)

    private fun buildRooms() {
        val shopCounter = f(120f, 170f, 640f, 210f, "#8B5A2B", L("پیشخوان", "Counter"))
        // ۰: خانه
        rooms.add(Room(L("خانه", "Home"), 760f, 460f, col("#6C5B4A"), listOf(
            f(250f, 190f, 520f, 330f, "#7A3B2E", null, false),
            f(30f, 30f, 200f, 120f, "#6B4F4F", L("تخت", "Bed")),
            f(300f, 220f, 460f, 300f, "#5C4033", L("میز", "Table")),
            f(560f, 30f, 730f, 80f, "#8A8D91", L("آشپزخانه", "Kitchen")),
            f(30f, 250f, 90f, 390f, "#2A2B2E", L("قفسه", "Shelf"))
        ), 380f, 370f, RectF(330f, 410f, 430f, 460f)))
        // ۱: نانوایی
        rooms.add(Room(L("نانوایی", "Bakery"), 760f, 460f, col("#CDB98F"), listOf(
            f(60f, 30f, 700f, 90f, "#B08D57", L("قفسه‌ی نان", "Bread shelf")), shopCounter,
            f(120f, 330f, 220f, 400f, "#8B5A2B", L("کیسه‌ی آرد", "Flour"))
        ), 380f, 380f, RectF(330f, 410f, 430f, 460f)))
        // ۲: داروخانه
        rooms.add(Room(L("داروخانه", "Pharmacy"), 760f, 460f, col("#DADDD8"), listOf(
            f(60f, 30f, 700f, 90f, "#9FB3B8", L("قفسه‌ی دارو", "Medicine shelves")),
            f(120f, 170f, 640f, 210f, "#E6E6E6", L("پیشخوان", "Counter")),
            f(600f, 300f, 700f, 400f, "#6FA58F", L("صندلی", "Seats"))
        ), 380f, 380f, RectF(330f, 410f, 430f, 460f)))
        // ۳: بقالی
        rooms.add(Room(L("بقالی", "Grocery"), 760f, 460f, col("#B9AD8A"), listOf(
            f(60f, 30f, 700f, 80f, "#7A6A4A", L("قفسه", "Shelf")), shopCounter,
            f(100f, 300f, 220f, 380f, "#9A7B4F", L("جعبه‌ها", "Crates")),
            f(540f, 300f, 660f, 380f, "#9A7B4F", L("جعبه‌ها", "Crates"))
        ), 380f, 380f, RectF(330f, 410f, 430f, 460f)))
    }

    // =====================================================================
    //  منطق مأموریت و دیالوگ
    // =====================================================================
    private fun showToast(msg: String) { toast = msg; toastT = 2.2f }

    private fun save() { Prefs.saveSlot(context, slot, s) }

    fun autoPause() {
        if (cur == null && shopId == null) paused = true
        save()
    }

    fun onBack() {
        when {
            shopId != null -> shopId = null
            cur != null -> { }
            paused && pauseMode != 0 -> pauseMode = 0
            else -> paused = !paused
        }
    }

    private fun startDialogue(list: List<Node>) {
        if (list.isEmpty()) return
        cur = list; dIdx = 0
        joyId = -1; joyDx = 0f; joyDy = 0f
        Sound.play("blip")
    }

    private fun endDialogue() {
        cur = null
        Story.progress(s)
        save()
    }

    private fun choose(c: Choice) {
        c.act?.invoke(s)
        Story.progress(s)
        Sound.play("click")
        when {
            c.shop != null -> { cur = null; shopId = c.shop }
            c.next.isEmpty() -> endDialogue()
            else -> { cur = c.next; dIdx = 0 }
        }
    }

    private fun advance() {
        val l = cur ?: return
        l[dIdx].act?.invoke(s)
        Story.progress(s)
        Sound.play("blip")
        if (dIdx < l.size - 1) dIdx++ else endDialogue()
    }

    private fun buy(it: Item) {
        if (it.outfit >= 0 && s.owned.contains(it.outfit)) {
            s.outfit = it.outfit; Sound.play("click"); return
        }
        if (s.money < it.price) {
            showToast(Lang.t("notenough")); Sound.play("error"); return
        }
        s.money -= it.price
        if (it.outfit >= 0) { s.owned.add(it.outfit); s.outfit = it.outfit } else s.add(it.id, 1)
        Story.progress(s)
        Sound.play("coin")
        showToast(Lang.t("bought") + ": " + it.name.s())
        save()
    }

    // =====================================================================
    //  تعامل
    // =====================================================================
    private fun nearest(): Any? {
        var best: Any? = null
        var bd = 1e9f
        for (n in npcs) {
            if (n.scene != s.scene) continue
            val dd = hypot(n.x - px, n.y - py)
            if (dd < 115f && dd < bd) { bd = dd; best = n }
        }
        if (s.scene < 0) {
            for (dr in doors) {
                val dd = hypot(dr.x - px, dr.y - py)
                if (dd < 75f && dd < bd) { bd = dd; best = dr }
            }
            for (o in objs) {
                if (o.id.startsWith("crate") && s.has(o.id)) continue
                val dd = hypot(o.x - px, o.y - py)
                if (dd < 70f && dd < bd) { bd = dd; best = o }
            }
        } else {
            val ex = rooms[s.scene].exit
            val dd = hypot(ex.centerX() - px, ex.centerY() - py)
            if (dd < 75f && dd < bd) { best = "exit" }
        }
        return best
    }

    private fun tryInteract() {
        when (val tg = nearest()) {
            is Npc -> startDialogue(Story.dialogue(tg.id, s))
            is Door -> {
                s.scene = tg.room
                px = rooms[tg.room].spawnX; py = rooms[tg.room].spawnY
                Sound.play("door"); Sound.setScene(false); save()
            }
            "exit" -> {
                val dr = doors.firstOrNull { it.room == s.scene }
                s.scene = -1
                if (dr != null) { px = dr.x; py = dr.y + 6f }
                Sound.play("door"); Sound.setScene(true); save()
            }
            is Obj -> touchObj(tg)
            else -> { showToast(Lang.t("nothing")); Sound.play("error") }
        }
    }

    private fun touchObj(o: Obj) {
        if (o.id.startsWith("crate")) {
            if (s.has("crate_q")) {
                s.set(o.id); Sound.play("coin")
                val k = (1..3).count { s.has("crate_$it") }
                showToast(if (Lang.fa) "جعبه برداشته شد (${Lang.num(k)}/۳)" else "Crate collected ($k/3)")
                save()
            } else {
                showToast(if (Lang.fa) "یک جعبه‌ی میوه. شاید صاحبی داشته باشد." else "A crate of fruit. Someone may be looking for it.")
            }
        } else {
            if (s.has("cat_q")) {
                s.set("cat_found"); Sound.play("coin")
                showToast(if (Lang.fa) "گربه را پیدا کردی! به امیر خبر بده." else "You found the cat! Tell Amir.")
                save()
            } else {
                showToast(if (Lang.fa) "یک گربه‌ی کوچک زیر درخت خوابیده." else "A small cat sleeps under a tree.")
            }
        }
    }

    // =====================================================================
    //  بروزرسانی
    // =====================================================================
    private fun update(dt: Float) {
        anim += dt
        if (toastT > 0) toastT -= dt
        if (!paused) {
            for (car in cars) {
                car.pos += car.speed * dt
                val lim = if (car.horizontal) WW else WH
                if (car.pos > lim + 120f) car.pos = -120f
                if (car.pos < -120f) car.pos = lim + 120f
            }
        }
        moving = false
        if (paused || cur != null || shopId != null) return
        s.minutes += dt

        var mx = 0f
        var my = 0f
        if (joyId != -1) {
            mx = joyDx / joyR; my = joyDy / joyR
            if (hypot(mx, my) < 0.15f) { mx = 0f; my = 0f }
        }
        if (kL) mx -= 1f
        if (kR) mx += 1f
        if (kU) my -= 1f
        if (kD) my += 1f
        val len = hypot(mx, my)
        if (len > 1f) { mx /= len; my /= len }
        if (len > 0.01f) {
            val nl = hypot(mx, my)
            fx = mx / nl; fy = my / nl
            val speed = if (running) 270f else 150f
            val ox = px; val oy = py
            moveAxis(mx * speed * dt, 0f)
            moveAxis(0f, my * speed * dt)
            val dist = hypot(px - ox, py - oy)
            if (dist > 0.01f) {
                moving = true
                walkPhase += dist * 0.16f
                stepAcc += dist
                if (stepAcc > (if (running) 48f else 34f)) { stepAcc = 0f; Sound.play("step") }
            }
        }
    }

    private fun blocked(nx: Float, ny: Float, r: Float): Boolean {
        if (s.scene < 0) {
            for (b in buildings) {
                tmp.set(b.r.left - r, b.r.top - r, b.r.right + r, b.r.bottom + r)
                if (tmp.contains(nx, ny)) return true
            }
        } else {
            for (fu in rooms[s.scene].furn) {
                if (!fu.solid) continue
                tmp.set(fu.r.left - r, fu.r.top - r, fu.r.right + r, fu.r.bottom + r)
                if (tmp.contains(nx, ny)) return true
            }
        }
        return false
    }

    private fun moveAxis(dx: Float, dy: Float) {
        val r = 14f
        val minB = if (s.scene < 0) r else 40f
        val maxX = if (s.scene < 0) WW - r else rooms[s.scene].w - 40f
        val maxY = if (s.scene < 0) WH - r else rooms[s.scene].h - 10f
        val nx = (px + dx).coerceIn(minB, maxX)
        val ny = (py + dy).coerceIn(minB, maxY)
        if (blocked(nx, ny, r)) return
        px = nx; py = ny
    }

    // =====================================================================
    //  ساعت و نور
    // =====================================================================
    private fun hourOfDay(): Float = (16.5f + s.minutes / 60f) % 24f

    private fun darkness(h: Float): Float = when {
        h in 7f..17f -> 0f
        h in 17f..20f -> (h - 17f) / 3f * 0.7f
        h >= 20f || h < 5f -> 0.7f
        else -> 0.7f * (1f - (h - 5f) / 2f)
    }

    // =====================================================================
    //  رسم
    // =====================================================================
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        btnInteract[0] = w - 80f * d; btnInteract[1] = h - 90f * d
        btnRun[0] = w - 190f * d; btnRun[1] = h - 60f * d
        btnPause[0] = w - 40f * d; btnPause[1] = 40f * d
        vignette = Paint().apply {
            shader = RadialGradient(
                w / 2f, h / 2f, max(w, h) * 0.75f,
                intArrayOf(Color.TRANSPARENT, Color.argb(150, 0, 0, 0)),
                floatArrayOf(0.55f, 1f), Shader.TileMode.CLAMP
            )
        }
    }

    private fun tx(cv: Canvas, str: String, x: Float, y: Float, size: Float, color: Int,
                   align: Paint.Align = Paint.Align.CENTER) {
        t.textSize = size; t.color = color; t.textAlign = align
        cv.drawText(str, x, y, t)
    }

    private fun endAlign(): Paint.Align = if (Lang.fa) Paint.Align.RIGHT else Paint.Align.LEFT

    override fun onDraw(canvas: Canvas) {
        btns.clear()
        val w = width.toFloat()
        val h = height.toFloat()
        val q = Prefs.quality(context)
        val hour = hourOfDay()
        val outdoor = s.scene < 0
        val dark = if (outdoor) darkness(hour) else 0f

        val ww = if (outdoor) WW else rooms[s.scene].w
        val wh = if (outdoor) WH else rooms[s.scene].h
        val vw = w / zoom
        val vh = h / zoom
        val camX = if (ww <= vw) (ww - vw) / 2f else (px - vw / 2f).coerceIn(0f, ww - vw)
        val camY = if (wh <= vh) (wh - vh) / 2f else (py - vh / 2f).coerceIn(0f, wh - vh)
        view.set(camX, camY, camX + vw, camY + vh)

        canvas.drawColor(if (outdoor) col("#B8A27A") else Color.BLACK)
        canvas.save()
        canvas.scale(zoom, zoom)
        canvas.translate(-camX, -camY)

        if (outdoor) {
            drawRoads(canvas, q)
            drawPark(canvas)
            drawBuildings(canvas, q, dark)
            drawProps(canvas)
            drawCars(canvas, q)
        } else {
            drawRoom(canvas, rooms[s.scene])
        }
        drawActors(canvas)

        if (outdoor) {
            if (dark > 0f) {
                p.style = Paint.Style.FILL
                p.color = Color.argb((dark * 255).toInt(), 8, 14, 38)
                canvas.drawRect(view, p)
                if (q >= 1 && dark > 0.25f) drawLamps(canvas)
            } else if (q >= 1 && hour in 16.5f..19.5f) {
                p.style = Paint.Style.FILL
                p.color = Color.argb(34, 255, 130, 45)
                canvas.drawRect(view, p)
            }
        }
        canvas.restore()

        if (outdoor && q >= 1) {
            if (Prefs.rain(context)) drawRain(canvas, q, w, h)
            if (dark < 0.3f) drawDust(canvas, w, h)
        }
        if (q >= 2) vignette?.let { canvas.drawRect(0f, 0f, w, h, it) }

        drawHud(canvas, w, h, hour)
        drawCinematicBars(canvas, w, h)
        cur?.let { drawDialogue(canvas, w, h, it) }
        shopId?.let { drawShop(canvas, w, h, it) }
        if (paused) drawPause(canvas, w, h)
    }

    // ---------------- بیرون ----------------
    private fun drawRoads(cv: Canvas, q: Int) {
        p.style = Paint.Style.FILL
        p.color = col("#9A9486")
        cv.drawRect(0f, 660f, WW, 940f, p)
        cv.drawRect(1060f, 0f, 1300f, WH, p)
        p.color = col("#3A3D40")
        cv.drawRect(0f, 700f, WW, 900f, p)
        cv.drawRect(1100f, 0f, 1260f, WH, p)
        p.color = col("#E8D9B0")
        var x = max(0f, view.left - (view.left % 90f))
        while (x < min(WW, view.right)) {
            if (x < 1090f || x > 1270f) cv.drawRect(x, 797f, x + 50f, 803f, p)
            x += 90f
        }
        var y = max(0f, view.top - (view.top % 90f))
        while (y < min(WH, view.bottom)) {
            if (y < 690f || y > 910f) cv.drawRect(1177f, y, 1183f, y + 50f, p)
            y += 90f
        }
        p.color = Color.argb(200, 235, 235, 235)
        for (i in 0 until 8) cv.drawRect(1110f + i * 18f, 708f, 1122f + i * 18f, 740f, p)
        if (q >= 1) {
            p.color = Color.argb(40, 0, 0, 0)
            cv.drawRect(0f, 660f, WW, 666f, p)
            cv.drawRect(0f, 934f, WW, 940f, p)
        }
    }

    private fun drawPark(cv: Canvas) {
        if (!RectF.intersects(view, park)) return
        p.style = Paint.Style.FILL
        p.color = col("#5E8C4A")
        cv.drawRoundRect(park, 18f, 18f, p)
        p.color = col("#B9A57C")
        cv.drawRect(park.left + 20f, park.centerY() - 14f, park.right - 20f, park.centerY() + 14f, p)
        // نیمکت‌ها
        p.color = col("#6B4A2B")
        for (bx in floatArrayOf(1480f, 1700f)) cv.drawRect(bx, 1415f, bx + 60f, 1431f, p)
        t.color = Color.WHITE
        tx(cv, if (Lang.fa) "پارک" else "Park", park.centerX(), park.top + 34f, 22f, Color.argb(200, 255, 255, 255))
    }

    private fun drawBuildings(cv: Canvas, q: Int, dark: Float) {
        for (b in buildings) {
            if (!RectF.intersects(view, b.r)) continue
            val r = b.r
            p.style = Paint.Style.FILL
            if (q >= 1) {
                p.color = Color.argb(70, 0, 0, 0)
                cv.drawRect(r.left + 10f, r.top + 12f, r.right + 10f, r.bottom + 12f, p)
            }
            p.color = b.color
            cv.drawRect(r, p)
            p.color = Color.argb(60, 0, 0, 0)
            cv.drawRect(r.left, r.top, r.right, r.top + 10f, p)
            if (q >= 1) {
                val cols = ((r.width() - 30f) / 56f).toInt()
                val rows = ((r.height() - 60f) / 70f).toInt()
                for (i in 0 until cols) for (j in 0 until rows) {
                    val wx = r.left + 24f + i * 56f
                    val wy = r.top + 30f + j * 70f
                    val lit = q >= 2 && dark > 0.3f && ((i * 7 + j * 3 + b.seed) % 3 != 0)
                    p.color = if (lit) col("#F6D87A") else col("#34495E")
                    cv.drawRect(wx, wy, wx + 22f, wy + 30f, p)
                }
            }
            val onTop = b.sign == "داروخانه" || b.sign == "میوه‌فروشی"
            p.color = col("#4A2F1C")
            when (b.kind) {
                2 -> cv.drawRect(r.centerX() - 80f, r.bottom - 46f, r.centerX() - 40f, r.bottom, p)
                1 -> if (onTop) cv.drawRect(r.centerX() - 30f, r.top, r.centerX() + 30f, r.top + 50f, p)
                     else cv.drawRect(r.centerX() - 30f, r.bottom - 50f, r.centerX() + 30f, r.bottom, p)
            }
            val sg = b.sign
            if (sg != null) {
                val sy = if (onTop) r.top + 56f else r.bottom - 112f
                p.color = col("#1E2A33")
                cv.drawRoundRect(r.left + 20f, sy, r.right - 20f, sy + 40f, 8f, 8f, p)
                tx(cv, sg, r.centerX(), sy + 29f, 26f, col("#F4E7B8"))
            }
            if (b.kind == 2) tx(cv, "خانه", r.centerX(), r.top + 40f, 22f, Color.WHITE)
        }
        // نشانگر درها
        for (dr in doors) {
            val bob = sin(anim * 4f) * 3f
            p.color = col("#FF7A1A")
            cv.drawCircle(dr.x, dr.y - 4f + bob, 5f, p)
        }
    }

    private fun drawProps(cv: Canvas) {
        for (sg in signs) {
            if (sg.x < view.left - 150f || sg.x > view.right + 150f) continue
            p.style = Paint.Style.FILL
            p.color = col("#2F4F3A")
            cv.drawRoundRect(sg.x - 85f, sg.y - 18f, sg.x + 85f, sg.y + 18f, 6f, 6f, p)
            tx(cv, sg.text, sg.x, sg.y + 7f, 20f, Color.WHITE)
        }
        for (pm in palms) {
            if (pm[0] < view.left - 60f || pm[0] > view.right + 60f) continue
            p.style = Paint.Style.FILL
            p.color = Color.argb(60, 0, 0, 0)
            cv.drawCircle(pm[0] + 8f, pm[1] + 8f, 26f, p)
            p.color = col("#6B4A2B")
            cv.drawCircle(pm[0], pm[1], 7f, p)
            p.color = col("#3E7A3A")
            for (k in 0 until 6) {
                val a = k * 1.047f + 0.3f + sin(anim * 0.8f + pm[0]) * 0.05f
                cv.drawCircle(pm[0] + cos(a) * 15f, pm[1] + sin(a) * 15f, 10f, p)
            }
            p.color = col("#4F9448")
            cv.drawCircle(pm[0], pm[1], 11f, p)
        }
        // اشیای تعاملی
        for (o in objs) {
            if (o.id.startsWith("crate") && s.has(o.id)) continue
            p.style = Paint.Style.FILL
            if (o.kind == 0) {
                p.color = col("#8B5A2B"); cv.drawRect(o.x - 16f, o.y - 12f, o.x + 16f, o.y + 12f, p)
                p.color = col("#D96B2B"); cv.drawCircle(o.x - 6f, o.y - 2f, 5f, p); cv.drawCircle(o.x + 6f, o.y + 2f, 5f, p)
            } else {
                p.color = col("#C98A3B"); cv.drawOval(o.x - 12f, o.y - 7f, o.x + 12f, o.y + 8f, p)
                cv.drawCircle(o.x + 11f, o.y - 4f, 6f, p)
                p.color = col("#C98A3B")
                cv.drawCircle(o.x + 8f, o.y - 10f, 2.5f, p); cv.drawCircle(o.x + 14f, o.y - 10f, 2.5f, p)
            }
        }
    }

    private fun drawLamps(cv: Canvas) {
        var x = 150f
        while (x < WW) {
            for (yy in floatArrayOf(664f, 936f)) {
                val lx = if (yy < 800f) x else x + 150f
                if (lx < view.left - 120f || lx > view.right + 120f) continue
                p.style = Paint.Style.FILL
                p.color = Color.argb(30, 255, 200, 110); cv.drawCircle(lx, yy, 90f, p)
                p.color = Color.argb(50, 255, 200, 110); cv.drawCircle(lx, yy, 55f, p)
                p.color = Color.argb(200, 255, 230, 150); cv.drawCircle(lx, yy, 6f, p)
            }
            x += 300f
        }
    }

    private fun drawCars(cv: Canvas, q: Int) {
        for (car in cars) {
            val cx = if (car.horizontal) car.pos else car.lane
            val cy = if (car.horizontal) car.lane else car.pos
            val hw = if (car.horizontal) 38f else 18f
            val hh = if (car.horizontal) 18f else 38f
            if (cx < view.left - 60f || cx > view.right + 60f || cy < view.top - 60f || cy > view.bottom + 60f) continue
            p.style = Paint.Style.FILL
            if (q >= 1) { p.color = Color.argb(70, 0, 0, 0); cv.drawRoundRect(cx - hw + 5f, cy - hh + 6f, cx + hw + 5f, cy + hh + 6f, 8f, 8f, p) }
            p.color = car.color
            cv.drawRoundRect(cx - hw, cy - hh, cx + hw, cy + hh, 8f, 8f, p)
            p.color = Color.argb(140, 20, 30, 40)
            val fw = if (car.speed > 0) 1f else -1f
            if (car.horizontal) cv.drawRect(cx + fw * 6f - 12f, cy - hh + 4f, cx + fw * 6f + 12f, cy + hh - 4f, p)
            else cv.drawRect(cx - hw + 4f, cy + fw * 6f - 12f, cx + hw - 4f, cy + fw * 6f + 12f, p)
        }
    }

    // ---------------- داخل ----------------
    private fun drawRoom(cv: Canvas, rm: Room) {
        p.style = Paint.Style.FILL
        p.color = rm.floor
        cv.drawRect(0f, 0f, rm.w, rm.h, p)
        // کاشی/تخته‌ی کف
        p.color = Color.argb(25, 0, 0, 0)
        var x = 0f
        while (x < rm.w) { cv.drawRect(x, 0f, x + 2f, rm.h, p); x += 60f }
        // دیوار
        p.color = col("#2A2B2E")
        cv.drawRect(0f, 0f, rm.w, 26f, p)
        cv.drawRect(0f, 0f, 26f, rm.h, p)
        cv.drawRect(rm.w - 26f, 0f, rm.w, rm.h, p)
        cv.drawRect(0f, rm.h - 8f, rm.w, rm.h, p)
        // پنجره
        p.color = col("#34495E")
        cv.drawRect(rm.w * 0.25f, 4f, rm.w * 0.25f + 70f, 22f, p)
        cv.drawRect(rm.w * 0.7f, 4f, rm.w * 0.7f + 70f, 22f, p)
        for (fu in rm.furn) {
            p.color = fu.color
            cv.drawRoundRect(fu.r, 6f, 6f, p)
            val lb = fu.label
            if (lb != null) tx(cv, lb.s(), fu.r.centerX(), fu.r.centerY() + 6f, 16f, Color.argb(220, 255, 255, 255))
        }
        // پادری در
        p.color = col("#FF7A1A")
        cv.drawRect(rm.exit.left, rm.exit.top + 24f, rm.exit.right, rm.exit.bottom, p)
        tx(cv, Lang.t("exit"), rm.exit.centerX(), rm.exit.top + 16f, 14f, Color.argb(220, 255, 255, 255))
        // نور گرم داخل
        p.color = Color.argb(28, 255, 190, 100)
        cv.drawRect(0f, 0f, rm.w, rm.h, p)
    }

    // ---------------- شخصیت‌ها ----------------
    private fun drawPerson(cv: Canvas, x: Float, y: Float, body: Int, hair: Int,
                           dx: Float, dy: Float, phase: Float, walking: Boolean, name: String?) {
        val bob = if (walking) kotlin.math.abs(sin(phase)) * -2.5f else sin(anim * 2f + x) * 0.8f
        p.style = Paint.Style.FILL
        p.color = Color.argb(75, 0, 0, 0)
        cv.drawOval(x - 14f, y - 4f, x + 14f, y + 14f, p)
        // پاها
        val sw = if (walking) sin(phase) * 6f else 0f
        val ppx = -dy; val ppy = dx
        p.color = col("#1B1B1D")
        cv.drawCircle(x + ppx * 5f + dx * sw, y + 8f + ppy * 2f + dy * sw, 4.5f, p)
        cv.drawCircle(x - ppx * 5f - dx * sw, y + 8f - ppy * 2f - dy * sw, 4.5f, p)
        // بدن
        p.color = body
        cv.drawRoundRect(x - 11f, y - 14f + bob, x + 11f, y + 8f + bob, 9f, 9f, p)
        p.color = Color.argb(50, 0, 0, 0)
        cv.drawRect(x - 11f, y + 3f + bob, x + 11f, y + 8f + bob, p)
        // سر
        p.color = hair
        cv.drawCircle(x + dx * 2f, y - 20f + bob, 8.5f, p)
        p.color = col("#E3B98E")
        cv.drawCircle(x + dx * 2.5f, y - 18f + dy * 1.5f + bob, 6.5f, p)
        if (name != null) tx(cv, name, x, y - 36f, 15f, Color.WHITE)
    }

    private fun targetPoint(): FloatArray? {
        val id = Story.target(s) ?: return null
        val n = npcs.firstOrNull { it.id == id } ?: return null
        if (n.scene == s.scene) return floatArrayOf(n.x, n.y)
        if (s.scene < 0) {
            val dr = doors.firstOrNull { it.room == n.scene } ?: return null
            return floatArrayOf(dr.x, dr.y)
        }
        val ex = rooms[s.scene].exit
        return floatArrayOf(ex.centerX(), ex.centerY())
    }

    private fun drawActors(cv: Canvas) {
        val tg = targetPoint()
        if (tg != null) {
            val pulse = 30f + sin(anim * 4f) * 5f
            p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = col("#FFD54A")
            cv.drawCircle(tg[0], tg[1], pulse, p)
            p.style = Paint.Style.FILL
        }
        for (n in npcs) {
            if (n.scene != s.scene) continue
            drawPerson(cv, n.x, n.y, n.body, n.hair, 0f, 1f, 0f, false, n.name.s())
        }
        drawPerson(cv, px, py, outfitColors[s.outfit.coerceIn(0, 3)], col("#222222"),
            fx, fy, walkPhase, moving, if (Lang.fa) "آرش" else "Arash")

        val near = nearest()
        if (near != null && cur == null && shopId == null) {
            val (nx, ny, label) = when (near) {
                is Npc -> Triple(near.x, near.y - 54f, Lang.t("talk"))
                is Door -> Triple(near.x, near.y - 30f, Lang.t("enter") + " " + near.label.s())
                is Obj -> Triple(near.x, near.y - 28f, Lang.t("examine"))
                else -> Triple(rooms[s.scene.coerceAtLeast(0)].exit.centerX(), rooms[s.scene.coerceAtLeast(0)].exit.top - 8f, Lang.t("exit"))
            }
            tx(cv, label, nx, ny + sin(anim * 6f) * 3f, 20f, col("#FFD54A"))
        }
    }

    private fun drawRain(cv: Canvas, q: Int, w: Float, h: Float) {
        val count = if (q >= 2) rainX.size else rainX.size / 2
        p.style = Paint.Style.FILL
        p.color = Color.argb(110, 200, 215, 235)
        p.strokeWidth = 2f
        for (i in 0 until count) {
            if (!paused && cur == null) {
                rainY[i] += 0.025f * (0.6f + (i % 5) * 0.15f)
                rainX[i] -= 0.004f
                if (rainY[i] > 1.1f) { rainY[i] = -0.1f; rainX[i] = Random.nextFloat() * 1.1f }
            }
            val x = rainX[i] * w
            val y = rainY[i] * h
            cv.drawLine(x, y, x - 6f, y + 18f, p)
        }
    }

    private fun drawDust(cv: Canvas, w: Float, h: Float) {
        p.style = Paint.Style.FILL
        p.color = Color.argb(60, 255, 235, 190)
        for (i in dustX.indices) {
            val x = ((dustX[i] * w + anim * 22f * (1f + (i % 3) * 0.4f)) % w)
            val y = (dustY[i] * h + sin(anim * 0.6f + i) * 16f)
            cv.drawCircle(x, y, 2f + (i % 3), p)
        }
    }

    // ---------------- رابط ----------------
    private fun circleBtn(cv: Canvas, b: FloatArray, label: String, on: Boolean = false) {
        p.style = Paint.Style.FILL
        p.color = Color.argb(if (on) 190 else 120, 20, 20, 22)
        cv.drawCircle(b[0], b[1], b[2], p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = Color.argb(220, 255, 122, 26)
        cv.drawCircle(b[0], b[1], b[2], p)
        p.style = Paint.Style.FILL
        tx(cv, label, b[0], b[1] + b[2] * 0.18f, b[2] * 0.45f, Color.WHITE)
    }

    private fun button(cv: Canvas, l: Float, tp_: Float, w: Float, h: Float, label: String,
                       enabled: Boolean = true, act: () -> Unit) {
        val r = RectF(l, tp_, l + w, tp_ + h)
        p.style = Paint.Style.FILL
        p.color = if (enabled) col("#17181A") else col("#101112")
        cv.drawRoundRect(r, 12f, 12f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f
        p.color = if (enabled) col("#FF7A1A") else col("#3A3B3E")
        cv.drawRoundRect(r, 12f, 12f, p)
        p.style = Paint.Style.FILL
        tx(cv, label, r.centerX(), r.centerY() + h * 0.18f, h * 0.38f, if (enabled) Color.WHITE else col("#6B6C70"))
        if (enabled) btns.add(Btn(r, act))
    }

    private fun clockStr(hour: Float): String {
        val hh = hour.toInt(); val mm = ((hour - hh) * 60f).toInt()
        return Lang.numStr(String.format(Locale.US, "%02d:%02d", hh, mm))
    }

    private fun drawHud(cv: Canvas, w: Float, h: Float, hour: Float) {
        val pad = 12f * d
        val pw = 300f * d
        p.style = Paint.Style.FILL
        p.color = Color.argb(165, 11, 11, 12)
        cv.drawRoundRect(pad, pad, pad + pw, pad + 78f * d, 14f, 14f, p)
        p.color = col("#FF7A1A")
        cv.drawRect(pad, pad + 10f * d, pad + 4f * d, pad + 68f * d, p)
        val al = endAlign()
        val ax = if (Lang.fa) pad + pw - 12f * d else pad + 16f * d
        tx(cv, Lang.t("clock") + " " + clockStr(hourOfDay()) + "   •   " + Lang.num(s.money) + " " + Lang.t("money"),
            ax, pad + 24f * d, 15f * d, col("#FFB070"), al)
        tx(cv, Story.objective(s).s(), ax, pad + 48f * d, 13f * d, Color.WHITE, al)
        val where = if (s.scene < 0) (if (Lang.fa) "محله‌ی گلستان" else "Golestan") else rooms[s.scene].name.s()
        tx(cv, where, ax, pad + 68f * d, 11f * d, col("#8A8D91"), al)

        circleBtn(cv, btnPause, "II")
        circleBtn(cv, btnInteract, Lang.t("interact"))
        circleBtn(cv, btnRun, Lang.t("run"), running)
        if (s.scene < 0) drawMinimap(cv, w, h)

        if (joyId != -1) {
            p.style = Paint.Style.FILL
            p.color = Color.argb(70, 255, 255, 255); cv.drawCircle(joyCx, joyCy, joyR, p)
            p.color = Color.argb(170, 255, 122, 26); cv.drawCircle(joyCx + joyDx, joyCy + joyDy, joyR * 0.45f, p)
        } else if (cur == null && !paused && shopId == null) {
            p.style = Paint.Style.FILL
            p.color = Color.argb(35, 255, 255, 255)
            cv.drawCircle(110f * d, h - 100f * d, joyR, p)
            tx(cv, Lang.t("hint_joy"), 110f * d, h - 96f * d, 12f * d, Color.argb(120, 255, 255, 255))
        }
        val ts = toast
        if (toastT > 0 && ts != null) {
            p.style = Paint.Style.FILL
            p.color = Color.argb(185, 11, 11, 12)
            cv.drawRoundRect(w / 2f - 190f * d, h * 0.2f, w / 2f + 190f * d, h * 0.2f + 40f * d, 12f, 12f, p)
            tx(cv, ts, w / 2f, h * 0.2f + 26f * d, 15f * d, Color.WHITE)
        }
    }

    private fun drawMinimap(cv: Canvas, w: Float, h: Float) {
        val mw = 150f * d
        val mh = mw * WH / WW
        val l = w - 12f * d - mw
        val tp_ = 76f * d
        val sx = mw / WW
        p.style = Paint.Style.FILL
        p.color = Color.argb(190, 11, 11, 12)
        cv.drawRoundRect(l - 4f, tp_ - 4f, l + mw + 4f, tp_ + mh + 4f, 8f, 8f, p)
        p.color = col("#3A3D40")
        cv.drawRect(l, tp_ + 700f * sx, l + mw, tp_ + 900f * sx, p)
        cv.drawRect(l + 1100f * sx, tp_, l + 1260f * sx, tp_ + mh, p)
        p.color = col("#5B5F63")
        for (b in buildings) cv.drawRect(l + b.r.left * sx, tp_ + b.r.top * sx, l + b.r.right * sx, tp_ + b.r.bottom * sx, p)
        p.color = col("#3E6B3A")
        cv.drawRect(l + park.left * sx, tp_ + park.top * sx, l + park.right * sx, tp_ + park.bottom * sx, p)
        val tg = targetPoint()
        if (tg != null && (anim * 3f).toInt() % 2 == 0) {
            p.color = Color.WHITE
            cv.drawCircle(l + tg[0] * sx, tp_ + tg[1] * sx, 4f * d, p)
        }
        p.color = col("#FF7A1A")
        cv.drawCircle(l + px * sx, tp_ + py * sx, 3.5f * d, p)
    }

    private fun drawCinematicBars(cv: Canvas, w: Float, h: Float) {
        val l = cur ?: return
        if (l[dIdx.coerceIn(0, l.size - 1)].who !== Story.NARR) return
        p.style = Paint.Style.FILL
        p.color = Color.BLACK
        cv.drawRect(0f, 0f, w, h * 0.13f, p)
        cv.drawRect(0f, h * 0.87f, w, h, p)
    }

    private fun drawDialogue(cv: Canvas, w: Float, h: Float, list: List<Node>) {
        val node = list[dIdx.coerceIn(0, list.size - 1)]
        val choices = node.choices.filter { it.ok?.invoke(s) ?: true }
        val left = 16f * d
        val right = w - 16f * d
        val tw = (right - left - 32f * d).toInt()
        if (dLayout == null || dLayoutNode !== node || dLayoutW != tw) {
            tp.textSize = 16f * d
            val str = node.text.s()
            dLayout = StaticLayout.Builder.obtain(str, 0, str.length, tp, tw)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setTextDirection(if (Lang.fa) TextDirectionHeuristics.RTL else TextDirectionHeuristics.LTR)
                .setLineSpacing(0f, 1.15f)
                .build()
            dLayoutNode = node; dLayoutW = tw
        }
        val lay = dLayout
        val textH = (lay?.height ?: 0).toFloat()
        val chH = 44f * d
        val boxH = 42f * d + textH + 12f * d + choices.size * (chH + 6f * d) + (if (choices.isEmpty()) 18f * d else 4f * d)
        val narr = node.who === Story.NARR
        val top = if (narr) h * 0.87f - boxH - 6f * d else h - boxH - 10f * d

        p.style = Paint.Style.FILL
        p.color = Color.argb(if (narr) 0 else 230, 11, 11, 12)
        cv.drawRoundRect(left, top, right, top + boxH, 18f, 18f, p)
        if (!narr) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = col("#FF7A1A")
            cv.drawRoundRect(left, top, right, top + boxH, 18f, 18f, p)
            p.style = Paint.Style.FILL
        }
        val ax = if (Lang.fa) right - 16f * d else left + 16f * d
        tx(cv, node.who.s(), ax, top + 26f * d, 17f * d, col("#FF7A1A"), endAlign())
        cv.save()
        cv.translate(left + 16f * d, top + 38f * d)
        lay?.draw(cv)
        cv.restore()

        var cy = top + 42f * d + textH + 8f * d
        for (c in choices) {
            button(cv, left + 16f * d, cy, right - left - 32f * d, chH, c.text.s()) { choose(c) }
            cy += chH + 6f * d
        }
        if (choices.isEmpty()) {
            tx(cv, Lang.t("tap_continue"), if (Lang.fa) left + 70f * d else right - 90f * d,
                top + boxH - 8f * d, 11f * d, col("#8A8D91"))
        }
    }

    private fun drawShop(cv: Canvas, w: Float, h: Float, id: String) {
        val shop = Story.shops[id] ?: return
        p.style = Paint.Style.FILL
        p.color = Color.argb(190, 0, 0, 0)
        cv.drawRect(0f, 0f, w, h, p)
        val pw = min(w * 0.85f, 560f * d)
        val rowH = 50f * d
        val ph = 90f * d + shop.items.size * (rowH + 8f * d) + 60f * d
        val l = (w - pw) / 2f
        val top = max(8f * d, (h - ph) / 2f)
        p.color = col("#17181A")
        cv.drawRoundRect(l, top, l + pw, top + ph, 18f, 18f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = col("#FF7A1A")
        cv.drawRoundRect(l, top, l + pw, top + ph, 18f, 18f, p)
        p.style = Paint.Style.FILL
        tx(cv, shop.title.s(), w / 2f, top + 36f * d, 24f * d, col("#FF7A1A"))
        tx(cv, Lang.num(s.money) + " " + Lang.t("money"), w / 2f, top + 62f * d, 15f * d, Color.WHITE)
        var y = top + 80f * d
        val al = endAlign()
        for (it in shop.items) {
            val r = RectF(l + 14f * d, y, l + pw - 14f * d, y + rowH)
            p.color = col("#222326"); cv.drawRoundRect(r, 10f, 10f, p)
            val nx = if (Lang.fa) r.right - 12f * d else r.left + 12f * d
            tx(cv, it.name.s(), nx, r.centerY() + 6f * d, 16f * d, Color.WHITE, al)
            val owned = it.outfit >= 0 && s.owned.contains(it.outfit)
            val wearing = owned && s.outfit == it.outfit
            val label = when {
                wearing -> Lang.t("wearing")
                owned -> Lang.t("wear")
                else -> Lang.num(it.price) + " " + Lang.t("money")
            }
            val bw = 120f * d
            val bx = if (Lang.fa) r.left + 8f * d else r.right - bw - 8f * d
            button(cv, bx, r.top + 6f * d, bw, rowH - 12f * d, label, !wearing) { buy(it) }
            y += rowH + 8f * d
        }
        button(cv, w / 2f - 90f * d, y + 4f * d, 180f * d, 44f * d, Lang.t("close")) { shopId = null }
    }

    private fun drawPause(cv: Canvas, w: Float, h: Float) {
        p.style = Paint.Style.FILL
        p.color = Color.argb(215, 6, 6, 7)
        cv.drawRect(0f, 0f, w, h, p)
        val bw = 280f * d; val bh = 46f * d
        val l = w / 2f - bw / 2f
        val al = endAlign()
        when (pauseMode) {
            0 -> {
                tx(cv, Lang.t("paused"), w / 2f, h * 0.17f, 32f * d, col("#FF7A1A"))
                val items = listOf<Pair<String, () -> Unit>>(
                    Lang.t("resume") to { paused = false },
                    Lang.t("missions") to { pauseMode = 1 },
                    Lang.t("inventory") to { pauseMode = 2 },
                    Lang.t("save") to { save(); showToast(Lang.t("saved")); paused = false },
                    Lang.t("quit") to { save(); onExit() }
                )
                var y = h * 0.24f
                for (it in items) { button(cv, l, y, bw, bh, it.first, true, it.second); y += bh + 10f * d }
            }
            1 -> {
                tx(cv, Lang.t("missions"), w / 2f, h * 0.14f, 28f * d, col("#FF7A1A"))
                var y = h * 0.22f
                val x = if (Lang.fa) w / 2f + 250f * d else w / 2f - 250f * d
                tx(cv, Lang.t("main_missions"), x, y, 15f * d, col("#8A8D91"), al); y += 24f * d
                for (e in Story.log(s)) {
                    val mark = if (e.done) "✓ " else if (e.active) "▸ " else ""
                    tx(cv, mark + e.title.s() + " — " + e.desc.s(), x, y, 14f * d,
                        if (e.done) col("#8A8D91") else Color.WHITE, al)
                    y += 22f * d
                }
                val side = Story.sideLog(s)
                if (side.isNotEmpty()) {
                    y += 10f * d
                    tx(cv, Lang.t("side_missions"), x, y, 15f * d, col("#8A8D91"), al); y += 24f * d
                    for (e in side) {
                        val mark = if (e.done) "✓ " else "▸ "
                        tx(cv, mark + e.title.s() + " — " + e.desc.s(), x, y, 14f * d,
                            if (e.done) col("#8A8D91") else Color.WHITE, al)
                        y += 22f * d
                    }
                }
                button(cv, l, h - 70f * d, bw, bh, Lang.t("back")) { pauseMode = 0 }
            }
            else -> {
                tx(cv, Lang.t("inventory"), w / 2f, h * 0.14f, 28f * d, col("#FF7A1A"))
                var y = h * 0.22f
                val x = if (Lang.fa) w / 2f + 250f * d else w / 2f - 250f * d
                tx(cv, Lang.t("items") + " — " + Lang.num(s.money) + " " + Lang.t("money"), x, y, 15f * d, col("#8A8D91"), al); y += 24f * d
                if (s.inv.isEmpty()) {
                    tx(cv, Lang.t("empty_inv"), x, y, 14f * d, Color.WHITE, al); y += 22f * d
                } else {
                    for ((k, v) in s.inv) {
                        tx(cv, Story.itemName(k).s() + " × " + Lang.num(v), x, y, 14f * d, Color.WHITE, al); y += 22f * d
                    }
                }
                y += 10f * d
                tx(cv, Lang.t("outfits"), x, y, 15f * d, col("#8A8D91"), al); y += 8f * d
                for (o in s.owned.sorted()) {
                    val lab = Story.outfitNames[o.coerceIn(0, 3)].s() + if (s.outfit == o) "  ✓" else ""
                    button(cv, l, y, bw, 38f * d, lab, s.outfit != o) { s.outfit = o }
                    y += 44f * d
                }
                button(cv, l, h - 62f * d, bw, 42f * d, Lang.t("back")) { pauseMode = 0 }
            }
        }
    }

    // =====================================================================
    //  ورودی
    // =====================================================================
    private fun hit(b: FloatArray, x: Float, y: Float) = hypot(x - b[0], y - b[1]) <= b[2] * 1.25f

    private fun onDown(id: Int, x: Float, y: Float) {
        // لایه‌های رویی (دکمه‌های رسم‌شده)
        val overlay = paused || shopId != null || cur != null
        if (overlay) {
            for (b in btns.reversed()) {
                if (b.r.contains(x, y)) { b.act(); return }
            }
            if (cur != null && !paused && shopId == null) {
                val l = cur!!
                val node = l[dIdx.coerceIn(0, l.size - 1)]
                val hasChoices = node.choices.any { it.ok?.invoke(s) ?: true }
                if (!hasChoices) advance()
            }
            return
        }
        when {
            hit(btnPause, x, y) -> { paused = true; pauseMode = 0 }
            hit(btnInteract, x, y) -> tryInteract()
            hit(btnRun, x, y) -> running = !running
            x < width * 0.5f && joyId == -1 -> { joyId = id; joyCx = x; joyCy = y; joyDx = 0f; joyDy = 0f }
        }
    }

    private fun onMove(id: Int, x: Float, y: Float) {
        if (id != joyId) return
        var dx = x - joyCx
        var dy = y - joyCy
        val l = hypot(dx, dy)
        if (l > joyR) { dx = dx / l * joyR; dy = dy / l * joyR }
        joyDx = dx; joyDy = dy
    }

    private fun onUp(id: Int) {
        if (id == joyId) { joyId = -1; joyDx = 0f; joyDy = 0f }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                onDown(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) onMove(e.getPointerId(i), e.getX(i), e.getY(i))
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> onUp(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> { joyId = -1; joyDx = 0f; joyDy = 0f }
        }
        return true
    }

    private fun setKey(code: Int, down: Boolean): Boolean {
        when (code) {
            KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_DPAD_LEFT -> kL = down
            KeyEvent.KEYCODE_D, KeyEvent.KEYCODE_DPAD_RIGHT -> kR = down
            KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_DPAD_UP -> kU = down
            KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_DPAD_DOWN -> kD = down
            KeyEvent.KEYCODE_SHIFT_LEFT -> running = down
            else -> return false
        }
        return true
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_E || keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_SPACE) {
            if (paused || shopId != null) return true
            val l = cur
            if (l != null) {
                val node = l[dIdx.coerceIn(0, l.size - 1)]
                if (node.choices.none { it.ok?.invoke(s) ?: true }) advance()
            } else tryInteract()
            return true
        }
        if (keyCode == KeyEvent.KEYCODE_ESCAPE) { onBack(); return true }
        return setKey(keyCode, true) || super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean =
        setKey(keyCode, false) || super.onKeyUp(keyCode, event)

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        requestFocus()
        last = System.nanoTime()
        handler.post(tick)
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(tick)
        super.onDetachedFromWindow()
    }
}
