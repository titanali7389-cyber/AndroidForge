package ir.hours77

import android.content.Context

/** تنظیمات و اسلات‌های ذخیره (۳ اسلات) */
object Prefs {
    const val SLOTS = 3

    private fun sp(c: Context) = c.getSharedPreferences("hours77", Context.MODE_PRIVATE)

    fun lang(c: Context): String = sp(c).getString("lang", "fa") ?: "fa"
    fun setLang(c: Context, v: String) { sp(c).edit().putString("lang", v).apply() }

    fun fps(c: Context): Int = sp(c).getInt("fps", 30)
    fun setFps(c: Context, v: Int) { sp(c).edit().putInt("fps", v).apply() }

    /** 0 = کم، 1 = متوسط، 2 = بالا */
    fun quality(c: Context): Int = sp(c).getInt("quality", 1)
    fun setQuality(c: Context, v: Int) { sp(c).edit().putInt("quality", v).apply() }

    fun rain(c: Context): Boolean = sp(c).getBoolean("rain", true)
    fun setRain(c: Context, v: Boolean) { sp(c).edit().putBoolean("rain", v).apply() }

    fun music(c: Context): Int = sp(c).getInt("music", 70)
    fun setMusic(c: Context, v: Int) { sp(c).edit().putInt("music", v).apply() }

    fun sfx(c: Context): Int = sp(c).getInt("sfx", 80)
    fun setSfx(c: Context, v: Int) { sp(c).edit().putInt("sfx", v).apply() }

    // ---- ذخیره ----
    fun slotData(c: Context, i: Int): String? = sp(c).getString("slot$i", null)
    fun slotTime(c: Context, i: Int): Long = sp(c).getLong("slot_t$i", 0L)
    fun lastSlot(c: Context): Int = sp(c).getInt("last_slot", -1)

    fun saveSlot(c: Context, i: Int, s: GameState) {
        sp(c).edit()
            .putString("slot$i", s.encode())
            .putLong("slot_t$i", System.currentTimeMillis())
            .putInt("last_slot", i)
            .apply()
    }

    fun deleteSlot(c: Context, i: Int) {
        val e = sp(c).edit().remove("slot$i").remove("slot_t$i")
        if (lastSlot(c) == i) e.putInt("last_slot", -1)
        e.apply()
    }

    fun hasSave(c: Context, i: Int): Boolean = GameState.decode(slotData(c, i)) != null

    fun continueSlot(c: Context): Int {
        val l = lastSlot(c)
        if (l >= 0 && hasSave(c, l)) return l
        for (i in 0 until SLOTS) if (hasSave(c, i)) return i
        return -1
    }

    fun firstFree(c: Context): Int {
        for (i in 0 until SLOTS) if (!hasSave(c, i)) return i
        return 0
    }
}
