package ir.hours77

import android.app.Activity
import android.os.Bundle

/** تنظیمات: زبان، نرخ فریم، کیفیت گرافیک، باران، صدا */
class SettingsActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.init(this)
        Ui.immersive(this)
        build()
    }

    override fun onResume() {
        super.onResume()
        Sound.start()
    }

    override fun onPause() {
        super.onPause()
        Sound.stop()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) Ui.immersive(this)
    }

    private fun build() {
        val col = Ui.column(this)
        col.addView(Ui.title(this, Lang.t("settings"), 30f))

        col.addView(Ui.button(this, Lang.t("language") + ": " + Lang.t("lang_name")) {
            Prefs.setLang(this, if (Lang.fa) "en" else "fa")
            Lang.init(this)
            build()
        })
        col.addView(Ui.button(this, Lang.t("fps") + ": " + Lang.num(Prefs.fps(this))) {
            Prefs.setFps(this, if (Prefs.fps(this) == 30) 60 else 30)
            build()
        })
        col.addView(Ui.button(this, Lang.t("quality") + ": " + Lang.t("q" + Prefs.quality(this))) {
            Prefs.setQuality(this, (Prefs.quality(this) + 1) % 3)
            build()
        })
        col.addView(Ui.button(this, Lang.t("rain") + ": " + Lang.t(if (Prefs.rain(this)) "on" else "off")) {
            Prefs.setRain(this, !Prefs.rain(this))
            Sound.refresh(this)
            build()
        })
        col.addView(Ui.button(this, Lang.t("music") + ": " + Lang.num(Prefs.music(this)) + "%") {
            Prefs.setMusic(this, (Prefs.music(this) + 25) % 125)
            Sound.refresh(this)
            build()
        })
        col.addView(Ui.button(this, Lang.t("sfx") + ": " + Lang.num(Prefs.sfx(this)) + "%") {
            Prefs.setSfx(this, (Prefs.sfx(this) + 25) % 125)
            Sound.refresh(this)
            build()
        })
        col.addView(Ui.label(this,
            if (Lang.fa) "کیفیت «کم» سایه‌ها و جلوه‌ها را کم می‌کند؛ برای گوشی‌های ضعیف مناسب است."
            else "Low quality reduces shadows and effects; best for weaker phones.", 12f))
        col.addView(Ui.button(this, Lang.t("back")) { finish() })

        setContentView(Ui.scroll(this, col))
    }
}
