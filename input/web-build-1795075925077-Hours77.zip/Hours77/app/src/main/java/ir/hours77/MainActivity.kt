package ir.hours77

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** منوی اصلی: START GAME / CONTINUE / LOAD GAME / SETTINGS / CREDITS / EXIT GAME */
class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.init(this)
        Sound.init(this)
        Ui.immersive(this)
    }

    override fun onResume() {
        super.onResume()
        Lang.init(this)
        Sound.refresh(this)
        Sound.setScene(true)
        Sound.start()
        build()
    }

    override fun onPause() {
        super.onPause()
        Sound.stop()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) Ui.immersive(this)
    }

    private fun startGame(slot: Int, newGame: Boolean) {
        startActivity(Intent(this, GameActivity::class.java)
            .putExtra("slot", slot).putExtra("new", newGame))
    }

    private fun build() {
        val root = FrameLayout(this)
        root.setBackgroundColor(Ui.BLACK)
        root.addView(MenuView(this))

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
            setPadding(Ui.dp(context, 40), Ui.dp(context, 12), Ui.dp(context, 40), Ui.dp(context, 36))
        }

        // ---- ستون عنوان ----
        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            val sb = SpannableStringBuilder("77 HOURS")
            sb.setSpan(ForegroundColorSpan(Ui.ORANGE), 0, 2, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.setSpan(ForegroundColorSpan(Ui.WHITE), 2, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            text = sb
            textSize = 52f
            typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            letterSpacing = 0.06f
        }
        val sub = TextView(this).apply {
            text = "A STORY FROM AHWAZ"
            textSize = 15f
            setTextColor(Ui.GREY)
            letterSpacing = 0.35f
            typeface = Typeface.DEFAULT_BOLD
        }
        val faTitle = TextView(this).apply {
            text = "۷۷ ساعت — داستانی از اهواز"
            textSize = 16f
            setTextColor(Ui.ORANGE)
        }
        val bar = View(this).apply {
            setBackgroundColor(Ui.ORANGE)
            layoutParams = LinearLayout.LayoutParams(Ui.dp(context, 90), Ui.dp(context, 3)).apply {
                topMargin = Ui.dp(context, 12); bottomMargin = Ui.dp(context, 10)
            }
        }
        left.addView(title); left.addView(bar); left.addView(sub); left.addView(faTitle)
        row.addView(left, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        // ---- ستون دکمه‌ها ----
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val cont = Prefs.continueSlot(this)
        val buttons = listOf(
            Ui.menuButton(this, "START GAME", "شروع بازی") {
                startGame(Prefs.firstFree(this), true)
            },
            Ui.menuButton(this, "CONTINUE", "ادامه", cont >= 0) {
                startGame(cont, false)
            },
            Ui.menuButton(this, "LOAD GAME", "بارگذاری بازی") {
                startActivity(Intent(this, SlotsActivity::class.java))
            },
            Ui.menuButton(this, "SETTINGS", "تنظیمات") {
                startActivity(Intent(this, SettingsActivity::class.java))
            },
            Ui.menuButton(this, "CREDITS", "سازندگان") {
                startActivity(Intent(this, CreditsActivity::class.java))
            },
            Ui.menuButton(this, "EXIT GAME", "خروج") { finishAffinity() }
        )
        buttons.forEachIndexed { i, b ->
            col.addView(b)
            b.alpha = 0f
            b.translationX = 60f
            b.animate().alpha(1f).translationX(0f).setStartDelay(150L + i * 90L).setDuration(380).start()
        }
        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(col)
        }
        row.addView(scroll, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))
        root.addView(row, FrameLayout.LayoutParams(-1, -1))

        title.alpha = 0f
        title.animate().alpha(1f).setDuration(900).start()

        // ---- پایین منو ----
        val footer = TextView(this).apply {
            text = "A TITANDEV PRODUCTION"
            textSize = 12f
            setTextColor(Ui.GREY)
            letterSpacing = 0.3f
            gravity = Gravity.CENTER
        }
        root.addView(footer, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply {
            bottomMargin = Ui.dp(this@MainActivity, 10)
        })
        val ver = TextView(this).apply {
            text = "v0.2 prototype"
            textSize = 10f
            setTextColor(Color.parseColor("#55585C"))
        }
        root.addView(ver, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply {
            bottomMargin = Ui.dp(this@MainActivity, 10); rightMargin = Ui.dp(this@MainActivity, 16)
        })

        setContentView(root)
    }
}
