package ir.hours77

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import kotlin.math.max
import kotlin.math.sin
import kotlin.random.Random

/** پس‌زمینه‌ی سینمایی متحرک منو: افق نارنجی، خط آسمان شهر، نخل‌ها و گردوغبار */
class MenuView(ctx: Context) : View(ctx) {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var sky: Paint? = null
    private var glow: Paint? = null
    private var vig: Paint? = null
    private val rnd = Random(7)
    private var farX = FloatArray(0); private var farW = FloatArray(0); private var farH = FloatArray(0)
    private var nearX = FloatArray(0); private var nearW = FloatArray(0); private var nearH = FloatArray(0)
    private var palmX = FloatArray(0)
    private val dustX = FloatArray(70) { Random.nextFloat() }
    private val dustY = FloatArray(70) { Random.nextFloat() }
    private val dustS = FloatArray(70) { 0.3f + Random.nextFloat() }
    private val t0 = System.nanoTime()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val hz = h * 0.68f
        sky = Paint().apply {
            shader = LinearGradient(0f, 0f, 0f, hz,
                intArrayOf(Color.parseColor("#050506"), Color.parseColor("#1B1410"), Color.parseColor("#8A3A12")),
                floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
        }
        glow = Paint().apply {
            shader = RadialGradient(w * 0.68f, hz, w * 0.55f,
                intArrayOf(Color.argb(150, 255, 122, 26), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        }
        vig = Paint().apply {
            shader = RadialGradient(w / 2f, h / 2f, max(w, h) * 0.75f,
                intArrayOf(Color.TRANSPARENT, Color.argb(190, 0, 0, 0)),
                floatArrayOf(0.5f, 1f), Shader.TileMode.CLAMP)
        }
        fun layer(count: Int, minH: Float, maxH: Float): Triple<FloatArray, FloatArray, FloatArray> {
            val xs = FloatArray(count); val ws = FloatArray(count); val hs = FloatArray(count)
            var x = 0f
            for (i in 0 until count) {
                xs[i] = x
                ws[i] = w / count.toFloat() * (0.8f + rnd.nextFloat() * 0.5f)
                hs[i] = h * (minH + rnd.nextFloat() * (maxH - minH))
                x += ws[i]
            }
            return Triple(xs, ws, hs)
        }
        val f = layer(16, 0.10f, 0.28f); farX = f.first; farW = f.second; farH = f.third
        val n = layer(10, 0.06f, 0.20f); nearX = n.first; nearW = n.second; nearH = n.third
        palmX = FloatArray(5) { w * (0.08f + it * 0.23f) }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val tt = (System.nanoTime() - t0) / 1e9f
        val hz = h * 0.68f

        sky?.let { c.drawRect(0f, 0f, w, h, it) }
        glow?.let { c.drawRect(0f, 0f, w, h, it) }

        // لایه‌ی دور
        p.color = Color.parseColor("#241A15")
        val offF = (tt * 6f) % totalW(farX, farW)
        drawLayer(c, farX, farW, farH, hz, -offF, w)
        // لایه‌ی نزدیک
        p.color = Color.parseColor("#0C0C0D")
        val offN = (tt * 12f) % totalW(nearX, nearW)
        drawLayer(c, nearX, nearW, nearH, h * 0.86f, -offN, w)

        // پنجره‌های روشن چشمک‌زن
        for (i in farX.indices) {
            if ((i * 7 + (tt * 0.4f).toInt()) % 4 == 0) {
                p.color = Color.argb(160, 255, 170, 60)
                val x = ((farX[i] - offF) % w + w) % w + farW[i] * 0.3f
                c.drawRect(x, hz - farH[i] + 14f, x + 5f, hz - farH[i] + 22f, p)
            }
        }

        // نخل‌ها
        p.color = Color.parseColor("#070707")
        p.strokeWidth = 6f
        for (px in palmX) {
            val x = ((px - offN * 1.2f) % w + w) % w
            val base = h * 0.92f
            val top = h * 0.58f
            val sway = sin(tt * 0.8f + px) * 6f
            c.drawLine(x, base, x + sway, top, p)
            for (k in 0 until 7) {
                val a = -2.6f + k * 0.45f
                c.drawLine(x + sway, top, x + sway + kotlin.math.cos(a) * 70f, top + sin(a) * 40f + 20f, p)
            }
        }
        // زمین
        p.color = Color.parseColor("#070707")
        c.drawRect(0f, h * 0.92f, w, h, p)

        // گردوغبار
        p.color = Color.argb(90, 255, 190, 120)
        for (i in dustX.indices) {
            val x = ((dustX[i] * w + tt * 18f * dustS[i]) % w)
            val y = (dustY[i] * h + sin(tt * 0.5f + i) * 14f)
            c.drawCircle(x, y, 1.5f * dustS[i] + 0.5f, p)
        }

        vig?.let { c.drawRect(0f, 0f, w, h, it) }
        postInvalidateOnAnimation()
    }

    private fun totalW(xs: FloatArray, ws: FloatArray): Float =
        if (xs.isEmpty()) 1f else max(1f, xs[xs.size - 1] + ws[ws.size - 1])

    private fun drawLayer(c: Canvas, xs: FloatArray, ws: FloatArray, hs: FloatArray, base: Float, off: Float, w: Float) {
        val tw = totalW(xs, ws)
        for (rep in 0..1) {
            for (i in xs.indices) {
                val x = xs[i] + off + rep * tw
                if (x > w || x + ws[i] < 0f) continue
                c.drawRect(x, base - hs[i], x + ws[i] - 3f, base + 400f, p)
            }
        }
    }
}
