package ir.hours77

import android.content.Context

/** سیستم دوزبانه‌ی فارسی / انگلیسی */
object Lang {
    var fa: Boolean = true

    fun init(c: Context) { fa = Prefs.lang(c) == "fa" }

    fun t(key: String): String = (if (fa) FA else EN)[key] ?: key

    fun num(n: Int): String = if (fa) Ui.faStr(n.toString()) else n.toString()

    fun numStr(s: String): String = if (fa) Ui.faStr(s) else s

    private val FA = mapOf(
        "settings" to "تنظیمات", "language" to "زبان", "lang_name" to "فارسی",
        "fps" to "نرخ فریم", "quality" to "کیفیت گرافیک",
        "q0" to "کم", "q1" to "متوسط", "q2" to "بالا",
        "rain" to "باران", "on" to "روشن", "off" to "خاموش",
        "music" to "موسیقی", "sfx" to "جلوه‌های صوتی", "back" to "بازگشت",
        "slot" to "اسلات", "empty" to "خالی", "load" to "بارگذاری", "delete" to "حذف",
        "load_title" to "بارگذاری بازی", "credits" to "سازندگان",
        "hint_joy" to "لمس کنید و بکشید", "interact" to "تعامل", "run" to "دویدن",
        "talk" to "گفتگو", "enter" to "ورود", "exit" to "خروج", "examine" to "بررسی",
        "resume" to "ادامه", "missions" to "مأموریت‌ها", "inventory" to "کوله‌پشتی و لباس",
        "save" to "ذخیره‌ی بازی", "saved" to "بازی ذخیره شد", "quit" to "خروج به منو",
        "money" to "تومان", "buy" to "خرید", "owned" to "دارید", "wear" to "پوشیدن",
        "wearing" to "تن شماست", "notenough" to "پول کافی نیست", "bought" to "خریداری شد",
        "close" to "بستن", "done" to "انجام شد", "main_missions" to "مأموریت اصلی",
        "side_missions" to "مأموریت‌های فرعی", "nothing" to "چیزی برای تعامل اینجا نیست",
        "clock" to "ساعت", "tap_continue" to "برای ادامه لمس کنید", "empty_inv" to "خالی است",
        "outfits" to "لباس‌ها", "items" to "وسایل", "paused" to "توقف", "indoor" to "داخل ساختمان",
        "mission" to "مأموریت", "min" to "دقیقه", "no_save" to "ذخیره‌ای وجود ندارد",
        "credits_back" to "برای بازگشت لمس کنید"
    )

    private val EN = mapOf(
        "settings" to "Settings", "language" to "Language", "lang_name" to "English",
        "fps" to "Frame rate", "quality" to "Graphics quality",
        "q0" to "Low", "q1" to "Medium", "q2" to "High",
        "rain" to "Rain", "on" to "On", "off" to "Off",
        "music" to "Music", "sfx" to "Sound effects", "back" to "Back",
        "slot" to "Slot", "empty" to "Empty", "load" to "Load", "delete" to "Delete",
        "load_title" to "Load game", "credits" to "Credits",
        "hint_joy" to "Touch and drag", "interact" to "Use", "run" to "Run",
        "talk" to "Talk", "enter" to "Enter", "exit" to "Exit", "examine" to "Examine",
        "resume" to "Resume", "missions" to "Missions", "inventory" to "Inventory & outfits",
        "save" to "Save game", "saved" to "Game saved", "quit" to "Quit to menu",
        "money" to "Toman", "buy" to "Buy", "owned" to "Owned", "wear" to "Wear",
        "wearing" to "Wearing", "notenough" to "Not enough money", "bought" to "Purchased",
        "close" to "Close", "done" to "Done", "main_missions" to "Main missions",
        "side_missions" to "Side missions", "nothing" to "Nothing to interact with here",
        "clock" to "Time", "tap_continue" to "Tap to continue", "empty_inv" to "Empty",
        "outfits" to "Outfits", "items" to "Items", "paused" to "Paused", "indoor" to "Indoors",
        "mission" to "Mission", "min" to "min", "no_save" to "No save found",
        "credits_back" to "Tap to go back"
    )
}
