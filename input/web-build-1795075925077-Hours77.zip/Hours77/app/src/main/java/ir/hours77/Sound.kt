package ir.hours77

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

/**
 * صدا: تمام صداها در همین کد تولید می‌شوند (بدون فایل صوتی خارجی)،
 * بنابراین حجم برنامه زیاد نمی‌شود و مشکل مجوز هم ندارد.
 * اگر روزی فایل صوتی حرفه‌ای داشتید، می‌توانید به جای این‌ها از SoundPool / MediaPlayer استفاده کنید.
 */
object Sound {
    private const val SR = 22050
    private val sfx = HashMap<String, AudioTrack>()
    private var music: AudioTrack? = null
    private var amb: AudioTrack? = null
    private var rain: AudioTrack? = null
    private var ready = false
    private var musicVol = 0.7f
    private var sfxVol = 0.8f
    private var outdoor = true
    private var rainOn = true
    private var running = false

    fun init(c: Context) {
        if (!ready) {
            try {
                sfx["click"] = track(gen(0.05f) { t -> sin(2 * PI * 900 * t).toFloat() * exp(-t * 60f) }, false)
                sfx["blip"] = track(gen(0.035f) { t -> sin(2 * PI * 620 * t).toFloat() * exp(-t * 70f) * 0.7f }, false)
                sfx["coin"] = track(gen(0.22f) { t ->
                    val f = if (t < 0.07f) 988.0 else 1319.0
                    sin(2 * PI * f * t).toFloat() * exp(-t * 14f)
                }, false)
                sfx["error"] = track(gen(0.16f) { t ->
                    (if (sin(2 * PI * 160 * t) > 0) 0.5f else -0.5f) * exp(-t * 12f)
                }, false)
                var prev = 0f
                sfx["step"] = track(gen(0.07f) { t ->
                    val nz = Random.nextFloat() * 2f - 1f
                    prev = prev * 0.7f + nz * 0.3f
                    prev * exp(-t * 55f) * 1.4f
                }, false)
                sfx["door"] = track(gen(0.25f) { t ->
                    (sin(2 * PI * (110 - t * 90) * t).toFloat() * 0.9f +
                        (Random.nextFloat() - 0.5f) * 0.2f) * exp(-t * 14f)
                }, false)
                music = track(makeMusic(), true)
                amb = track(makeAmbience(), true)
                rain = track(makeRain(), true)
                ready = true
            } catch (e: Throwable) {
                ready = false
            }
        }
        refresh(c)
    }

    fun refresh(c: Context) {
        musicVol = Prefs.music(c) / 100f
        sfxVol = Prefs.sfx(c) / 100f
        rainOn = Prefs.rain(c)
        applyVolumes()
    }

    /** بیرون یا داخل ساختمان */
    fun setScene(isOutdoor: Boolean) {
        outdoor = isOutdoor
        applyVolumes()
    }

    private fun applyVolumes() {
        if (!ready) return
        try {
            music?.setVolume(musicVol * 0.55f)
            amb?.setVolume(sfxVol * (if (outdoor) 0.5f else 0.15f))
            rain?.setVolume(if (rainOn) sfxVol * (if (outdoor) 0.35f else 0.1f) else 0f)
        } catch (e: Throwable) { }
    }

    fun start() {
        if (!ready || running) return
        try {
            music?.play(); amb?.play(); rain?.play()
            running = true
        } catch (e: Throwable) { }
    }

    fun stop() {
        if (!ready) return
        try {
            music?.pause(); amb?.pause(); rain?.pause()
        } catch (e: Throwable) { }
        running = false
    }

    fun play(name: String) {
        if (!ready || sfxVol <= 0f) return
        try {
            val t = sfx[name] ?: return
            t.stop()
            t.reloadStaticData()
            t.setVolume(sfxVol * (if (name == "step") 0.5f else 1f))
            t.play()
        } catch (e: Throwable) { }
    }

    // ------------------------ تولید صدا ------------------------

    private fun gen(sec: Float, f: (Float) -> Float): ShortArray {
        val n = (SR * sec).toInt()
        val out = ShortArray(n)
        for (i in 0 until n) {
            val v = f(i.toFloat() / SR).coerceIn(-1f, 1f)
            out[i] = (v * 26000f).toInt().toShort()
        }
        return out
    }

    private fun track(data: ShortArray, loop: Boolean): AudioTrack {
        val at = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SR)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(data.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        at.write(data, 0, data.size)
        if (loop) at.setLoopPoints(0, data.size, -1)
        return at
    }

    /** موسیقی: پد آرام در لا مینور + چند نت زنگ‌مانند (۸ ثانیه، بی‌درز) */
    private fun makeMusic(): ShortArray {
        val dur = 8f
        val chord = doubleArrayOf(110.0, 165.0, 220.0, 262.0, 330.0)
        val notes = arrayOf(floatArrayOf(0f, 440f), floatArrayOf(2.5f, 392f), floatArrayOf(5f, 330f), floatArrayOf(6.4f, 294f))
        return gen(dur) { t ->
            var v = 0f
            for ((i, f) in chord.withIndex()) {
                val trem = 0.6f + 0.4f * sin(2 * PI * 0.125 * (i + 1) * t).toFloat()
                v += sin(2 * PI * f * t).toFloat() * trem * 0.11f
            }
            for (nt in notes) {
                val dt = t - nt[0]
                if (dt >= 0f) v += sin(2 * PI * nt[1] * dt).toFloat() * exp(-dt * 1.6f) * 0.22f
            }
            v
        }
    }

    /** صدای ترافیک و شهر: غرش پایین + عبور ماشین */
    private fun makeAmbience(): ShortArray {
        val dur = 8f
        var lp = 0f
        return gen(dur) { t ->
            lp = lp * 0.985f + (Random.nextFloat() * 2f - 1f) * 0.06f
            val swell = 0.55f + 0.25f * sin(2 * PI * 0.125 * t).toFloat()
            var pass = 0f
            for (c in floatArrayOf(1.6f, 5.4f)) {
                val d = (t - c)
                pass += exp(-d * d * 1.2f) * 0.9f
            }
            val edge = minOf(1f, minOf(t, dur - t) / 0.25f)
            lp * (swell + pass) * 5f * edge
        }
    }

    private fun makeRain(): ShortArray {
        val dur = 4f
        var prev = 0f
        return gen(dur) { t ->
            val nz = Random.nextFloat() * 2f - 1f
            val hp = nz - prev
            prev = nz
            val edge = minOf(1f, minOf(t, dur - t) / 0.2f)
            hp * 0.25f * edge
        }
    }
}
