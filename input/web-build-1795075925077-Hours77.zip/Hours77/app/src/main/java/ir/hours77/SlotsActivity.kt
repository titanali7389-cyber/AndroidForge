package ir.hours77

import android.app.Activity
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** LOAD GAME: سه اسلات ذخیره */
class SlotsActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.init(this)
        Ui.immersive(this)
    }

    override fun onResume() {
        super.onResume()
        Sound.start()
        build()
    }

    override fun onPause() {
        super.onPause()
        Sound.stop()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) Ui.immersive(this)
    }

    private fun build() {
        val col = Ui.column(this)
        col.addView(Ui.title(this, Lang.t("load_title"), 30f))

        for (i in 0 until Prefs.SLOTS) {
            val st = GameState.decode(Prefs.slotData(this, i))
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = if (Lang.fa) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
                background = GradientDrawable().apply {
                    cornerRadius = Ui.dp(context, 8).toFloat()
                    setColor(Ui.PANEL)
                    setStroke(Ui.dp(context, 1), Ui.GREY)
                }
                setPadding(Ui.dp(context, 14), Ui.dp(context, 8), Ui.dp(context, 14), Ui.dp(context, 8))
            }
            val info = TextView(this).apply {
                textSize = 14f
                setTextColor(Ui.WHITE)
                text = if (st == null) {
                    Lang.t("slot") + " " + Lang.num(i + 1) + " — " + Lang.t("empty")
                } else {
                    val hour = (16.5f + st.minutes / 60f) % 24f
                    val hh = hour.toInt(); val mm = ((hour - hh) * 60f).toInt()
                    val date = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(Prefs.slotTime(context, i)))
                    Lang.t("slot") + " " + Lang.num(i + 1) + " — " + Story.objective(st).s() + "\n" +
                        Lang.t("money") + ": " + Lang.num(st.money) + "  |  " +
                        Lang.t("clock") + " " + Lang.numStr(String.format(Locale.US, "%02d:%02d", hh, mm)) +
                        "  |  " + Lang.numStr(date)
                }
            }
            row.addView(info, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            if (st != null) {
                row.addView(Ui.button(this, Lang.t("load"), true, 90) {
                    startActivity(Intent(this, GameActivity::class.java)
                        .putExtra("slot", i).putExtra("new", false))
                })
                row.addView(Ui.button(this, Lang.t("delete"), true, 90) {
                    Prefs.deleteSlot(this, i)
                    build()
                })
            }
            col.addView(row, LinearLayout.LayoutParams(Ui.dp(this, 620), LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = Ui.dp(this@SlotsActivity, 10)
            })
        }
        col.addView(Ui.button(this, Lang.t("back")) { finish() })
        setContentView(Ui.scroll(this, col))
    }
}
