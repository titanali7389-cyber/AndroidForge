package ir.hours77

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** ابزارهای رابط کاربری — رنگ‌بندی: مشکی، خاکستری، نارنجی، سفید */
object Ui {
    val BLACK: Int = Color.parseColor("#0B0B0C")
    val PANEL: Int = Color.parseColor("#17181A")
    val GREY: Int = Color.parseColor("#8A8D91")
    val ORANGE: Int = Color.parseColor("#FF7A1A")
    val WHITE: Int = Color.parseColor("#F2F2F2")

    private val faDigits = charArrayOf('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')

    fun faStr(s: String): String =
        s.map { if (it in '0'..'9') faDigits[it - '0'] else it }.joinToString("")

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    private fun dir(): Int = if (Lang.fa) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR

    fun column(ctx: Context): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        layoutDirection = dir()
        setBackgroundColor(BLACK)
        setPadding(dp(ctx, 24), dp(ctx, 16), dp(ctx, 24), dp(ctx, 16))
    }

    fun scroll(ctx: Context, content: View): ScrollView = ScrollView(ctx).apply {
        isFillViewport = true
        setBackgroundColor(BLACK)
        addView(content)
    }

    fun title(ctx: Context, text: String, sp: Float): TextView = TextView(ctx).apply {
        this.text = text
        textSize = sp
        setTextColor(ORANGE)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
    }

    fun label(ctx: Context, text: String, sp: Float, color: Int = GREY): TextView =
        TextView(ctx).apply {
            this.text = text
            textSize = sp
            setTextColor(color)
            gravity = Gravity.CENTER
            setPadding(0, dp(ctx, 6), 0, 0)
        }

    private fun box(ctx: Context, enabled: Boolean): GradientDrawable = GradientDrawable().apply {
        cornerRadius = dp(ctx, 8).toFloat()
        setColor(if (enabled) PANEL else Color.parseColor("#101112"))
        setStroke(dp(ctx, 2), if (enabled) ORANGE else Color.parseColor("#3A3B3E"))
    }

    fun button(ctx: Context, text: String, enabled: Boolean = true, w: Int = 280, onClick: () -> Unit): Button =
        Button(ctx).apply {
            this.text = text
            textSize = 16f
            isAllCaps = false
            setTextColor(if (enabled) WHITE else Color.parseColor("#5A5C60"))
            background = box(ctx, enabled)
            stateListAnimator = null
            isEnabled = enabled
            setOnClickListener { Sound.play("click"); onClick() }
            layoutParams = LinearLayout.LayoutParams(dp(ctx, w), dp(ctx, 46)).apply {
                topMargin = dp(ctx, 8)
            }
        }

    /** دکمه‌ی منوی اصلی: عنوان انگلیسی + زیرعنوان فارسی */
    fun menuButton(ctx: Context, en: String, fa: String, enabled: Boolean = true, onClick: () -> Unit): Button =
        Button(ctx).apply {
            val sb = SpannableStringBuilder(en + "\n" + fa)
            sb.setSpan(RelativeSizeSpan(0.7f), en.length + 1, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.setSpan(ForegroundColorSpan(if (enabled) ORANGE else Color.parseColor("#4A4B4E")),
                en.length + 1, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            text = sb
            textSize = 17f
            letterSpacing = 0.08f
            typeface = Typeface.DEFAULT_BOLD
            isAllCaps = false
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
            setPadding(dp(ctx, 20), 0, dp(ctx, 20), 0)
            setTextColor(if (enabled) WHITE else Color.parseColor("#5A5C60"))
            background = box(ctx, enabled)
            stateListAnimator = null
            isEnabled = enabled
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setOnClickListener { Sound.play("click"); onClick() }
            layoutParams = LinearLayout.LayoutParams(dp(ctx, 300), dp(ctx, 52)).apply {
                topMargin = dp(ctx, 6)
            }
        }

    @Suppress("DEPRECATION")
    fun immersive(a: Activity) {
        a.window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = a.window.attributes
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            a.window.attributes = lp
        }
    }
}
