package ir.hours77

/** متن دوزبانه */
class L(val fa: String, val en: String) {
    fun s(): String = if (Lang.fa) fa else en
}

class Choice(
    val text: L,
    val next: List<Node> = emptyList(),
    val act: ((GameState) -> Unit)? = null,
    val shop: String? = null,
    val ok: ((GameState) -> Boolean)? = null
)

class Node(
    val who: L,
    val text: L,
    val choices: List<Choice> = emptyList(),
    val act: ((GameState) -> Unit)? = null
)

class Item(val id: String, val name: L, val price: Int, val outfit: Int = -1)
class Shop(val title: L, val items: List<Item>)
class Entry(val title: L, val desc: L, val done: Boolean, val active: Boolean)

/**
 * داستان فصل اول: «شب اول».
 * همه‌ی شخصیت‌ها و رویدادها تخیلی‌اند.
 * برای افزودن مأموریت یا دیالوگ جدید فقط همین فایل را گسترش دهید.
 */
object Story {
    val NARR = L("روایت", "Narration")
    private val ARASH = L("آرش", "Arash")
    private val GRAN = L("مادربزرگ", "Grandma")
    private val BAKER = L("کریم نانوا", "Karim the baker")
    private val PHARM = L("دکتر نیلوفر", "Dr. Niloufar")
    private val SARA = L("سارا", "Sara")
    private val JALAL = L("عمو جلال", "Uncle Jalal")
    private val AMIR = L("امیر", "Amir")
    private val GROC = L("آقا بهروز", "Mr. Behrouz")
    private val VEND = L("فروشنده", "Vendor")

    private fun n(who: L, fa: String, en: String, act: ((GameState) -> Unit)? = null) =
        Node(who, L(fa, en), emptyList(), act)

    private fun c(
        fa: String, en: String, next: List<Node> = emptyList(),
        act: ((GameState) -> Unit)? = null, shop: String? = null,
        ok: ((GameState) -> Boolean)? = null
    ) = Choice(L(fa, en), next, act, shop, ok)

    // ------------------------------------------------------------------
    //  فروشگاه‌ها
    // ------------------------------------------------------------------
    val shops: Map<String, Shop> = mapOf(
        "bakery" to Shop(L("نانوایی", "Bakery"), listOf(
            Item("bread", L("نان تازه", "Fresh bread"), 5),
            Item("cookie", L("کلوچه", "Cookie"), 8))),
        "pharmacy" to Shop(L("داروخانه", "Pharmacy"), listOf(
            Item("meds", L("قرص‌های مادربزرگ", "Grandma's pills"), 25),
            Item("bandage", L("باند و چسب زخم", "Bandages"), 6))),
        "grocery" to Shop(L("بقالی", "Grocery"), listOf(
            Item("water", L("آب معدنی", "Water"), 3),
            Item("tea", L("چای", "Tea"), 12))),
        "fruit" to Shop(L("میوه‌فروشی", "Fruit stand"), listOf(
            Item("fruit", L("میوه‌ی تازه", "Fresh fruit"), 8))),
        "clothes" to Shop(L("بساط لباس", "Clothes stall"), listOf(
            Item("outfit1", L("کاپشن نارنجی", "Orange jacket"), 35, 1),
            Item("outfit2", L("هودی مشکی", "Black hoodie"), 40, 2),
            Item("outfit3", L("پالتوی سبز", "Green coat"), 30, 3)))
    )

    fun itemName(id: String): L = when (id) {
        "bread" -> L("نان", "Bread")
        "cookie" -> L("کلوچه", "Cookie")
        "meds" -> L("قرص مادربزرگ", "Grandma's pills")
        "bandage" -> L("باند", "Bandages")
        "water" -> L("آب", "Water")
        "tea" -> L("چای", "Tea")
        "fruit" -> L("میوه", "Fruit")
        else -> L(id, id)
    }

    val outfitNames = arrayOf(
        L("لباس معمولی", "Everyday clothes"), L("کاپشن نارنجی", "Orange jacket"),
        L("هودی مشکی", "Black hoodie"), L("پالتوی سبز", "Green coat")
    )

    // ------------------------------------------------------------------
    //  پیشرفت مأموریت
    // ------------------------------------------------------------------
    fun progress(s: GameState) {
        if (s.main == 1 && s.n("bread") > 0) s.main = 2
        if (s.main == 2 && s.n("meds") > 0) s.main = 3
    }

    private val mainTitles = listOf(
        L("شب اول", "The First Night"),
        L("نان", "Bread"),
        L("قرص‌ها", "The Pills"),
        L("سارا", "Sara"),
        L("بازگشت", "Coming Home"),
        L("پایان فصل اول", "End of Chapter 1")
    )

    private val mainDescs = listOf(
        L("با مادربزرگ صحبت کن.", "Talk to Grandma."),
        L("از نانوایی نان بخر.", "Buy bread at the bakery."),
        L("از داروخانه قرص‌ها را بخر.", "Buy the pills at the pharmacy."),
        L("در کوچه با سارا صحبت کن.", "Talk to Sara in the alley."),
        L("قرص‌ها را به مادربزرگ برسان.", "Bring the pills home to Grandma."),
        L("در محله قدم بزن و به مردم کمک کن.", "Walk the neighborhood and help people.")
    )

    fun objective(s: GameState): L = mainDescs[s.main.coerceIn(0, mainDescs.size - 1)]

    /** شناسه‌ی NPC هدف مأموریت اصلی */
    fun target(s: GameState): String? = when (s.main) {
        0, 4 -> "gran"
        1 -> "baker"
        2 -> "pharm"
        3 -> "sara"
        else -> null
    }

    private fun crates(s: GameState): Int =
        (1..3).count { s.has("crate_$it") }

    fun log(s: GameState): List<Entry> {
        val out = ArrayList<Entry>()
        for (i in 0 until mainTitles.size) {
            if (i <= s.main) out.add(Entry(mainTitles[i], mainDescs[i], s.main > i, s.main == i))
        }
        return out
    }

    fun sideLog(s: GameState): List<Entry> {
        val out = ArrayList<Entry>()
        if (s.has("crate_q")) {
            val k = crates(s)
            out.add(Entry(
                L("جعبه‌های عمو جلال", "Uncle Jalal's crates"),
                L("جعبه‌های میوه را پیدا کن (${Lang.numStr("$k")}/۳)", "Find the fruit crates ($k/3)"),
                s.has("crate_done"), !s.has("crate_done")))
        }
        if (s.has("cat_q")) {
            out.add(Entry(
                L("گربه‌ی گمشده", "The lost cat"),
                if (s.has("cat_found")) L("به امیر خبر بده.", "Tell Amir you found it.")
                else L("گربه‌ی امیر را در پارک پیدا کن.", "Find Amir's cat in the park."),
                s.has("cat_done"), !s.has("cat_done")))
        }
        return out
    }

    // ------------------------------------------------------------------
    //  مقدمه
    // ------------------------------------------------------------------
    fun intro(): List<Node> = listOf(
        n(NARR, "اهواز. زمستان. ساعت‌هاست که اینترنت قطع است و شهر نفسش را نگه داشته.",
            "Ahvaz. Winter. The internet has been down for hours, and the city is holding its breath."),
        n(NARR, "محله‌ی گلستان آرام‌تر از همیشه است؛ آدم‌ها کمتر حرف می‌زنند و بیشتر گوش می‌دهند.",
            "Golestan is quieter than usual; people talk less and listen more."),
        n(NARR, "این داستان تخیلی است. شخصیت‌ها و اتفاقات آن واقعی نیستند.",
            "This is a work of fiction. Its characters and events are not real.")
    )

    // ------------------------------------------------------------------
    //  دیالوگ‌ها
    // ------------------------------------------------------------------
    private fun shopTalk(who: L, fa: String, en: String, shop: String, extra: List<Choice> = emptyList()): List<Node> =
        listOf(Node(who, L(fa, en),
            listOf(c("خرید", "Buy", shop = shop)) + extra + listOf(c("خداحافظ", "Leave"))))

    fun dialogue(id: String, s: GameState): List<Node> = when (id) {
        "gran" -> gran(s)
        "baker" -> baker(s)
        "pharm" -> pharm(s)
        "sara" -> sara(s)
        "jalal" -> jalal(s)
        "amir" -> amir(s)
        "groc" -> shopTalk(GROC, "بفرمایید جوون. چای تازه دم کردم.", "Welcome. I just brewed fresh tea.", "grocery")
        "cloth" -> shopTalk(VEND, "لباس گرم داریم، شب‌ها هوا سرد می‌شه.", "Warm clothes here. The nights get cold.", "clothes")
        else -> emptyList()
    }

    private fun gran(s: GameState): List<Node> {
        val giveStart: (GameState) -> Unit = { it.money += 32; it.main = 1 }
        return when {
            s.main == 0 -> listOf(
                n(GRAN, "آرش جان، قرص‌هام ته کشیده. امشب بدون‌شون خوابم نمی‌بره.",
                    "Arash, my pills are finished. I won't sleep tonight without them."),
                n(ARASH, "اینترنت که قطعه، ولی خیابون هنوز بازه. من می‌رم داروخانه.",
                    "The internet is down, but the street is still open. I'll go to the pharmacy."),
                Node(GRAN, L("این پول رو بگیر؛ کارت‌خوان‌ها کار نمی‌کنن. یه نون هم بگیر. مواظب خودت باش.",
                    "Take this cash; the card machines aren't working. Get some bread too. Be careful."),
                    listOf(
                        c("چشم، نگران نباشید.", "I will. Don't worry.",
                            listOf(n(GRAN, "خدا پشت و پناهت.", "God keep you safe.")), act = giveStart),
                        c("مطمئنید؟ بیرون اوضاع عجیبه.", "Are you sure? Things feel strange outside.",
                            listOf(n(GRAN, "عجیبه، ولی دارو که صبر نمی‌کنه. برو و زود برگرد.",
                                "It is strange, but medicine can't wait. Go, and come back soon.")), act = giveStart)
                    ))
            )
            s.main in 1..3 -> listOf(
                n(GRAN, "زود برگرد پسرم. تا شب کوچه‌ها خلوت می‌شن.",
                    "Come back soon, son. By night the alleys empty out.")
            )
            s.main == 4 -> listOf(
                n(ARASH, "مادربزرگ، قرص‌هاتون.", "Grandma, here are your pills.") { it.add("meds", -1) },
                n(GRAN, "دستت درد نکنه عزیزم.", "Thank you, my dear."),
                Node(GRAN, L("بگو ببینم، بیرون چی دیدی؟", "Tell me, what did you see out there?"),
                    listOf(
                        c("همه‌چیز رو تعریف می‌کنم.", "I'll tell you everything.", ending(s, true),
                            act = { it.kind += 1; it.main = 5 }),
                        c("آروم بود؛ نگران نباشید.", "It was calm. Don't worry.", ending(s, false),
                            act = { it.main = 5 })
                    ))
            )
            else -> listOf(
                n(GRAN, "برو استراحت کن. خدا کنه زودتر همه‌چیز آروم بشه.",
                    "Go and rest. I hope everything calms down soon.")
            )
        }
    }

    private fun ending(s: GameState, truth: Boolean): List<Node> {
        val out = ArrayList<Node>()
        if (truth) out.add(n(NARR, "مادربزرگ ساکت گوش داد و دستت را گرفت: «ترس بد نیست، تنها موندن بده.»",
            "Grandma listened in silence and took your hand: \"Fear isn't the worst thing. Being alone is.\""))
        else out.add(n(NARR, "لبخند زدی و او هم لبخند زد؛ هر دو می‌دانستید همه‌ی حرف‌ها گفته نشده.",
            "You smiled and she smiled back; you both knew not everything had been said."))
        if (s.has("crate_done") || s.has("cat_done") || s.has("gave_sara_bread"))
            out.add(n(NARR, "کمک‌هایی که امشب کردی را همسایه‌ها فراموش نمی‌کنند.",
                "The neighbors will not forget the help you gave tonight."))
        out.add(n(NARR, "پایان فصل اول. «۷۷ ساعت» ادامه دارد.", "End of Chapter 1. 77 HOURS continues."))
        return out
    }

    private fun baker(s: GameState): List<Node> {
        val chat = c("از اوضاع محله بپرسم؟", "Ask about the neighborhood", listOf(
            n(BAKER, "اینترنت که قطعه، مردم از هم خبر می‌گیرن. هر کی نون می‌گیره یه خبری هم می‌آره.",
                "With the internet down, people ask after each other. Everyone who buys bread brings some news."),
            n(BAKER, "ولی نگران نباش؛ محله‌ی ما همیشه کنار هم بوده.",
                "But don't worry. This neighborhood has always stood together.")
        ), act = { it.set("heard_baker") })
        return if (s.main == 1)
            shopTalk(BAKER, "سلام آرش! مادربزرگت خوبه؟ نون می‌خوای؟ هر نون ۵ تومنه.",
                "Hey Arash! How's your grandmother? Need bread? It's 5 toman a loaf.", "bakery", listOf(chat))
        else
            shopTalk(BAKER, "سلام پسرم. نون تازه‌ست.", "Hello, son. The bread is fresh.", "bakery", listOf(chat))
    }

    private fun pharm(s: GameState): List<Node> {
        val extra = ArrayList<Choice>()
        if (s.main == 2 && s.n("meds") == 0 && s.money < 25) {
            extra.add(c("پولم کمه... می‌شه بعداً حساب کنم؟", "I'm short... can I pay later?",
                listOf(n(PHARM, "تو پسر همون مادربزرگی. باشه، ببر. فردا حساب می‌کنیم.",
                    "You're that grandmother's boy. Fine, take them. We'll settle up tomorrow.")),
                act = { it.add("meds", 1); it.set("owes_pharm") },
                ok = { st -> st.kind >= 1 }))
        }
        val g = if (s.main == 2)
            L("سلام آرش. قرص‌های مادربزرگت ۲۵ تومنه. سیستم قطعه، فقط پول نقد.",
                "Hello Arash. Your grandmother's pills are 25 toman. The system is down, cash only.")
        else
            L("بفرمایید، در خدمتم.", "How can I help?")
        return shopTalk(PHARM, g.fa, g.en, "pharmacy", extra)
    }

    private fun sara(s: GameState): List<Node> = when {
        s.main == 3 -> listOf(
            n(SARA, "آرش! داداشمو ندیدی؟ از ظهر خبری ازش ندارم و گوشی‌ها هم که کار نمی‌کنن.",
                "Arash! Have you seen my brother? No word since noon, and the phones don't work."),
            Node(SARA, L("نمی‌دونم چیکار کنم...", "I don't know what to do..."), listOf(
                c("نونم رو باهات تقسیم می‌کنم.", "I'll share my bread with you.",
                    listOf(n(SARA, "ممنون... خدا خیرت بده.", "Thank you... bless you.")),
                    act = { it.add("bread", -1); it.kind += 1; it.set("gave_sara_bread"); it.main = 4 },
                    ok = { st -> st.n("bread") > 0 }),
                c("کنارت می‌مونم و گوش می‌دم.", "I'll stay and listen.",
                    listOf(n(SARA, "حرف زدن باهات سبکم کرد. برو، مادربزرگت منتظره.",
                        "Talking to you helped. Go, your grandmother is waiting.")),
                    act = { it.kind += 1; it.main = 4 }),
                c("باید عجله کنم.", "I have to hurry.",
                    listOf(n(SARA, "باشه، برو. خدا به همراهت.", "Alright, go. Take care.")),
                    act = { it.main = 4 })
            ))
        )
        s.main < 3 -> listOf(n(SARA, "هوا سنگینه امشب، نه؟", "The air feels heavy tonight, doesn't it?"))
        else -> listOf(n(SARA, "اگه از داداشم خبر شد بهت می‌گم.", "If I hear from my brother, I'll let you know."))
    }

    private fun jalal(s: GameState): List<Node> {
        val shopC = c("خرید میوه", "Buy fruit", shop = "fruit")
        val bye = c("خداحافظ", "Leave")
        return when {
            !s.has("crate_q") -> listOf(Node(JALAL,
                L("پسرم، یه کمکی می‌کنی؟ سه تا جعبه‌ی میوه تو کوچه‌ها افتاده، نمی‌تونم خودم برم دنبالشون.",
                    "Son, can you help? Three crates of fruit were left in the alleys and I can't fetch them myself."),
                listOf(
                    c("باشه، می‌رم دنبالشون.", "Sure, I'll find them.",
                        listOf(n(JALAL, "دستت درد نکنه! دو تاشون نزدیک چهارراه و یکی اون سر کوچه‌ست.",
                            "Bless you! Two are near the junction, one is at the far end of the street.")),
                        act = { it.set("crate_q") }),
                    shopC, bye)))
            crates(s) < 3 -> listOf(Node(JALAL,
                L("جعبه‌ها رو پیدا کردی؟ هنوز ${Lang.numStr("${crates(s)}")} تا از ۳ تا رو آوردی.",
                    "Found the crates? You've gathered ${crates(s)} of 3 so far."),
                listOf(shopC, bye)))
            !s.has("crate_done") -> listOf(
                n(JALAL, "همه‌شون رو آوردی! بیا، این مزد زحمتته.", "You got them all! Here, for your trouble.") {
                    it.money += 18; it.kind += 1; it.set("crate_done")
                })
            else -> listOf(Node(JALAL, L("میوه‌ی تازه داریم.", "Fresh fruit today."), listOf(shopC, bye)))
        }
    }

    private fun amir(s: GameState): List<Node> = when {
        !s.has("cat_q") -> listOf(Node(AMIR,
            L("آقا... گربه‌م گم شده. می‌شه کمکم کنی؟", "Mister... my cat is lost. Can you help me?"),
            listOf(
                c("باشه، پیداش می‌کنم.", "Okay, I'll find her.",
                    listOf(n(AMIR, "آخ جون! عاشق پارکه، شاید اونجا باشه.", "Yay! She loves the park, maybe she's there.")),
                    act = { it.set("cat_q") }),
                c("الان وقت ندارم.", "I don't have time now.",
                    listOf(n(AMIR, "باشه...", "Okay..."))))))
        !s.has("cat_found") -> listOf(n(AMIR, "تو پارک دنبالش بگرد، لطفاً.", "Please look for her in the park."))
        !s.has("cat_done") -> listOf(
            n(AMIR, "پیداش کردی! ممنون! این هم یه چیزی که پس‌انداز کرده بودم.",
                "You found her! Thank you! Here, it's something I saved up.") {
                it.money += 12; it.kind += 1; it.set("cat_done")
            })
        else -> listOf(n(AMIR, "گربه‌م خوابیده. ممنون که کمکم کردی!", "She's asleep now. Thanks for helping me!"))
    }
}
