package ir.hours77

import android.animation.ObjectAnimator
import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.animation.LinearInterpolator
import android.widget.LinearLayout
import android.widget.ScrollView

/** CREDITS: متن متحرک رو به بالا؛ با لمس بسته می‌شود */
class CreditsActivity : Activity() {

    private var anim: ObjectAnimator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.init(this)
        Ui.immersive(this)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Ui.BLACK)
            val h = resources.displayMetrics.heightPixels
            setPadding(Ui.dp(context, 24), h, Ui.dp(context, 24), h)
        }
        fun big(s: String) = col.addView(Ui.title(this, s, 34f))
        fun mid(s: String) = col.addView(Ui.label(this, s, 20f, Ui.WHITE))
        fun small(s: String) = col.addView(Ui.label(this, s, 14f, Ui.GREY))
        fun gap() = col.addView(Ui.label(this, " ", 26f))

        big("77 HOURS")
        small("A STORY FROM AHWAZ")
        gap()
        small("A TITANDEV PRODUCTION")
        gap(); gap()
        mid(if (Lang.fa) "داستان و طراحی" else "Story & Design")
        small("TITANDEV")
        gap()
        mid(if (Lang.fa) "برنامه‌نویسی" else "Programming")
        small(if (Lang.fa) "TITANDEV با کمک Claude" else "TITANDEV with Claude")
        gap()
        mid(if (Lang.fa) "صدا و موسیقی" else "Audio")
        small(if (Lang.fa) "تولیدشده با کد درون خود بازی" else "Generated in code inside the game")
        gap()
        mid(if (Lang.fa) "یادداشت" else "Note")
        small(if (Lang.fa) "این بازی اثری تخیلی است. شخصیت‌ها و اتفاقات آن واقعی نیستند."
        else "This is a work of fiction. Its characters and events are not real.")
        gap(); gap()
        small(Lang.t("credits_back"))

        val sv = ScrollView(this).apply {
            setBackgroundColor(Ui.BLACK)
            isVerticalScrollBarEnabled = false
            addView(col)
            setOnClickListener { finish() }
            setOnTouchListener { _, e ->
                if (e.action == android.view.MotionEvent.ACTION_UP) finish()
                true
            }
        }
        setContentView(sv)
        sv.post {
            val max = col.height - sv.height
            if (max > 0) {
                anim = ObjectAnimator.ofInt(sv, "scrollY", 0, max).apply {
                    duration = 32000
                    interpolator = LinearInterpolator()
                    start()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        Sound.start()
    }

    override fun onPause() {
        super.onPause()
        Sound.stop()
    }

    override fun onDestroy() {
        anim?.cancel()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) Ui.immersive(this)
    }
}
