package ir.hours77

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import java.util.Locale
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * موتور بازی نمونه‌ی اولیه‌ی «۷۷ ساعت».
 * نمای از بالا (top-down) از بخشی خیالی‌شده از محله‌ی گلستان اهواز.
 * شامل: حرکت، دویدن، تعامل، دیالوگ، مأموریت، شب و روز، باران، ترافیک، ذخیره و بارگذاری.
 */
class GameView(
    ctx: Context,
    continueGame: Boolean,
    private val onExit: () -> Unit
) : View(ctx) {

    // ---------- مدل‌های داده ----------
    private class Bld(val r: RectF, val kind: Int, val color: Int, val sign: String?, val seed: Int)
    private class Npc(val id: Int, val name: String, val x: Float, val y: Float, val color: Int)
    private class Car(var pos: Float, val lane: Float, val speed: Float, val color: Int, val horizontal: Boolean)
    private class Sign(val x: Float, val y: Float, val text: String)
    private class Line(val who: String, val text: String)

    // ---------- دنیا ----------
    private val WW = 2400f
    private val WH = 1600f
    private val buildings = ArrayList<Bld>()
    private val npcs = ArrayList<Npc>()
    private val cars = ArrayList<Car>()
    private val signs = ArrayList<Sign>()
    private val palms = ArrayList<FloatArray>()

    private val d = resources.displayMetrics.density

    // ---------- وضعیت بازی ----------
    private var px = 860f
    private var py = 690f
    private var fx = 0f
    private var fy = 1f
    private var stage = 0
    private var hasMeds = false
    private var minutes = 0f
    private var paused = false
    private var running = false
    private var toast: String? = null
    private var toastT = 0f
    private var anim = 0f

    private var dlg: List<Line>? = null
    private var dIdx = 0
    private var dAction: (() -> Unit)? = null
    private var dLayout: StaticLayout? = null
    private var dLayoutIdx = -1
    private var dLayoutW = 0

    // ---------- ورودی ----------
    private var joyId = -1
    private var joyCx = 0f
    private var joyCy = 0f
    private var joyDx = 0f
    private var joyDy = 0f
    private var joyR = 60f * d
    private var kL = false
    private var kR = false
    private var kU = false
    private var kD = false

    private val btnInteract = floatArrayOf(0f, 0f, 44f * d)
    private val btnRun = floatArrayOf(0f, 0f, 32f * d)
    private val btnPause = floatArrayOf(0f, 0f, 24f * d)
    private val pauseBtns = Array(3) { RectF() }

    // ---------- ابزار رسم ----------
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val tmp = RectF()
    private val view = RectF()
    private var vignette: Paint? = null

    private val rainX = FloatArray(140) { Random.nextFloat() }
    private val rainY = FloatArray(140) { Random.nextFloat() }

    // ---------- حلقه‌ی بازی ----------
    private val handler = Handler(Looper.getMainLooper())
    private var last = 0L
    private val tick = object : Runnable {
        override fun run() {
            val start = System.nanoTime()
            val dt = min(0.05f, (start - last) / 1e9f)
            last = start
            update(dt)
            invalidate()
            val frameMs = 1000L / Prefs.fps(context)
            val spent = (System.nanoTime() - start) / 1_000_000L
            handler.postDelayed(this, max(1L, frameMs - spent))
        }
    }

    init {
        isFocusable = true
        isFocusableInTouchMode = true
        buildWorld()
        if (continueGame) {
            Prefs.load(ctx)?.let {
                stage = it.stage; hasMeds = it.hasMeds
                px = it.x; py = it.y; minutes = it.minutes
            }
        }
    }

    // =====================================================================
    //  ساخت دنیا
    // =====================================================================
    private fun c(s: String) = Color.parseColor(s)

    private fun addB(x: Float, y: Float, w: Float, h: Float, kind: Int, color: String, sign: String? = null) {
        buildings.add(Bld(RectF(x, y, x + w, y + h), kind, c(color), sign, buildings.size * 13 + 5))
    }

    private fun buildWorld() {
        val brick = "#B5835A"; val sand = "#C9AE85"; val cream = "#D9C9A3"; val clay = "#A8734E"; val grey = "#9A978F"

        // شمال غربی
        addB(650f, 400f, 320f, 240f, 2, cream)          // خانه‌ی بازیکن
        addB(60f, 380f, 260f, 260f, 0, brick)
        addB(360f, 420f, 240f, 220f, 0, sand)
        addB(60f, 60f, 300f, 240f, 0, clay)
        addB(400f, 80f, 260f, 250f, 0, grey)
        addB(720f, 80f, 280f, 240f, 0, brick)
        // شمال شرقی
        addB(1330f, 440f, 260f, 200f, 1, "#8FAE9B", "نانوایی")
        addB(1640f, 440f, 240f, 200f, 1, "#C9A06B", "بقالی")
        addB(1930f, 400f, 300f, 240f, 0, brick)
        addB(1330f, 80f, 300f, 260f, 0, sand)
        addB(1680f, 80f, 260f, 260f, 0, clay)
        addB(1980f, 60f, 340f, 260f, 0, grey)
        // جنوب غربی
        addB(760f, 960f, 280f, 220f, 1, "#E6E6DC", "داروخانه")
        addB(60f, 980f, 260f, 260f, 0, sand)
        addB(360f, 1000f, 300f, 220f, 0, brick)
        addB(60f, 1300f, 300f, 240f, 0, grey)
        addB(400f, 1280f, 260f, 260f, 0, clay)
        addB(760f, 1260f, 280f, 260f, 0, cream)
        // جنوب شرقی
        addB(1330f, 960f, 260f, 200f, 1, "#B9D07A", "میوه‌فروشی")
        addB(1640f, 980f, 260f, 240f, 0, brick)
        addB(1950f, 960f, 330f, 260f, 0, sand)
        addB(1330f, 1260f, 300f, 260f, 0, grey)
        addB(1680f, 1280f, 260f, 240f, 0, cream)
        addB(1980f, 1300f, 340f, 240f, 0, clay)

        npcs.add(Npc(0, "مادربزرگ", 810f, 658f, c("#7A4E8C")))
        npcs.add(Npc(1, "نانوا", 1460f, 662f, c("#E0A33A")))
        npcs.add(Npc(2, "داروساز", 900f, 930f, c("#3C8D7B")))

        cars.add(Car(200f, 750f, 140f, c("#D9D9D9"), true))
        cars.add(Car(1300f, 750f, 170f, c("#C9A227"), true))
        cars.add(Car(900f, 850f, -150f, c("#6E8FB3"), true))
        cars.add(Car(1900f, 850f, -120f, c("#B04A3F"), true))
        cars.add(Car(300f, 1150f, 130f, c("#D9D9D9"), false))
        cars.add(Car(1200f, 1210f, -140f, c("#4E5D6A"), false))

        signs.add(Sign(300f, 668f, "خیابان اصلی"))
        signs.add(Sign(1180f, 578f, "محله‌ی گلستان"))
        signs.add(Sign(2100f, 668f, "خیابان اصلی"))
        signs.add(Sign(1180f, 1350f, "کوچه‌ی گلستان"))

        for (x in floatArrayOf(120f, 520f, 1020f, 1400f, 1800f, 2200f)) palms.add(floatArrayOf(x, 682f))
        for (x in floatArrayOf(240f, 680f, 1100f, 1500f, 2000f)) palms.add(floatArrayOf(x, 920f))
    }

    // =====================================================================
    //  وضعیت‌ها و مأموریت
    // =====================================================================
    private fun objective(): String = when (stage) {
        0 -> "با مادربزرگ جلوی خانه صحبت کن"
        1 -> "به نانوایی برو و با نانوا حرف بزن"
        2 -> "به داروخانه برو و قرص‌ها را بگیر"
        3 -> "قرص‌ها را به مادربزرگ برسان"
        else -> "پایان نمونه‌ی اولیه — در محله قدم بزن"
    }

    private fun targetNpc(): Npc? = when (stage) {
        0, 3 -> npcs[0]
        1 -> npcs[1]
        2 -> npcs[2]
        else -> null
    }

    private fun dl(lines: List<Line>, act: (() -> Unit)? = null): Pair<List<Line>, (() -> Unit)?> = Pair(lines, act)

    private fun dialogueFor(n: Npc): Pair<List<Line>, (() -> Unit)?> {
        return when (n.id) {
            0 -> when (stage) {
                0 -> dl(listOf(
                    Line("مادربزرگ", "آرش جان، قرص‌هام تموم شده. امشب بدون‌شون نمی‌تونم بخوابم."),
                    Line("آرش", "نگران نباشید مادربزرگ. اینترنت که قطعه، ولی خیابون هنوز رفت‌وآمد داره. من می‌رم."),
                    Line("مادربزرگ", "اول به نانوا سر بزن؛ اون همیشه خبر داره کدوم مغازه بازه. مواظب خودت باش.")
                )) { stage = 1; autoSave() }
                1, 2 -> dl(listOf(Line("مادربزرگ", "زود برگرد پسرم. تا شب کوچه‌ها خلوت می‌شن.")), null)
                3 -> dl(listOf(
                    Line("آرش", "مادربزرگ، قرص‌هاتون."),
                    Line("مادربزرگ", "دستت درد نکنه عزیزم. توی این روزهای سخت، همه‌مون یاد گرفتیم به هم تکیه کنیم."),
                    Line("روایت", "(از دور صدای شهر می‌آید. شب آرام‌تر از همیشه است، و فردا روز دیگری است.)")
                )) { hasMeds = false; stage = 4; autoSave() }
                else -> dl(listOf(Line("مادربزرگ", "برو استراحت کن. خدا کنه زودتر همه‌چیز آروم بشه.")), null)
            }
            1 -> when (stage) {
                1 -> dl(listOf(
                    Line("نانوا", "سلام آرش! مادربزرگت خوبه؟"),
                    Line("آرش", "قرص‌هاش تموم شده. می‌دونید داروخانه بازه؟"),
                    Line("نانوا", "آره، داروخانه‌ی اون طرف خیابون هنوز بازه. ولی کارت‌خوان کار نمی‌کنه، پول نقد ببر. این نون گرم رو هم ببر برای مادربزرگ.")
                )) { stage = 2; autoSave() }
                0 -> dl(listOf(Line("نانوا", "سلام پسرم. نون تازه‌ست، ولی امروز مشتری کمتره.")), null)
                else -> dl(listOf(Line("نانوا", "خدا به همراهت. این روزها همه نگران همدیگه‌ایم.")), null)
            }
            else -> when (stage) {
                2 -> dl(listOf(
                    Line("داروساز", "بفرمایید. سیستم قطعه، ولی نسخه‌ی قبلی مادربزرگت رو یادمه."),
                    Line("آرش", "این هم پول نقد."),
                    Line("داروساز", "بیا، این قرص‌ها. زود برو خونه؛ هوا داره تاریک می‌شه.")
                )) { hasMeds = true; stage = 3; autoSave() }
                0, 1 -> dl(listOf(Line("داروساز", "کاری داشتی بیا. تا دیروقت بازم.")), null)
                else -> dl(listOf(Line("داروساز", "مراقب خودت باش.")), null)
            }
        }
    }

    private fun startDialogue(n: Npc) {
        val (lines, act) = dialogueFor(n)
        dlg = lines; dIdx = 0; dAction = act; dLayoutIdx = -1
        joyId = -1; joyDx = 0f; joyDy = 0f
    }

    private fun advanceDialogue() {
        val l = dlg ?: return
        if (dIdx < l.size - 1) {
            dIdx++
        } else {
            val a = dAction
            dlg = null; dAction = null
            a?.invoke()
        }
    }

    private fun nearestNpc(): Npc? =
        npcs.filter { hypot(it.x - px, it.y - py) < 100f * 1f }
            .minByOrNull { hypot(it.x - px, it.y - py) }

    private fun tryInteract() {
        val n = nearestNpc()
        if (n == null) showToast("چیزی برای تعامل اینجا نیست") else startDialogue(n)
    }

    private fun showToast(s: String) { toast = s; toastT = 2.2f }

    private fun autoSave() {
        Prefs.save(context, SaveData(stage, hasMeds, px, py, minutes))
    }

    fun autoPause() {
        if (dlg == null) paused = true
        autoSave()
    }

    fun togglePause() {
        if (dlg != null) return
        paused = !paused
    }

    // =====================================================================
    //  بروزرسانی
    // =====================================================================
    private fun update(dt: Float) {
        anim += dt
        if (toastT > 0) toastT -= dt

        // ترافیک همیشه در حال حرکت است (حتی در دیالوگ)
        if (!paused) {
            for (car in cars) {
                car.pos += car.speed * dt
                val lim = if (car.horizontal) WW else WH
                if (car.pos > lim + 120f) car.pos = -120f
                if (car.pos < -120f) car.pos = lim + 120f
            }
        }
        if (paused || dlg != null) return

        minutes += dt   // هر ثانیه‌ی واقعی = یک دقیقه‌ی بازی

        var mx = 0f
        var my = 0f
        if (joyId != -1) {
            mx = joyDx / joyR; my = joyDy / joyR
            if (hypot(mx, my) < 0.15f) { mx = 0f; my = 0f }
        }
        if (kL) mx -= 1f
        if (kR) mx += 1f
        if (kU) my -= 1f
        if (kD) my += 1f
        val len = hypot(mx, my)
        if (len > 1f) { mx /= len; my /= len }

        if (len > 0.01f) {
            val nl = hypot(mx, my)
            fx = mx / nl
            fy = my / nl
            val speed = if (running) 270f else 150f
            moveAxis(mx * speed * dt, 0f)
            moveAxis(0f, my * speed * dt)
        }
    }

    private fun moveAxis(dx: Float, dy: Float) {
        val r = 14f
        val nx = (px + dx).coerceIn(r, WW - r)
        val ny = (py + dy).coerceIn(r, WH - r)
        for (b in buildings) {
            tmp.set(b.r.left - r, b.r.top - r, b.r.right + r, b.r.bottom + r)
            if (tmp.contains(nx, ny)) return
        }
        px = nx; py = ny
    }

    // =====================================================================
    //  ساعت و نور
    // =====================================================================
    private fun hourOfDay(): Float = (16.5f + minutes / 60f) % 24f

    /** مقدار تاریکی بین ۰ و ۱ */
    private fun darkness(h: Float): Float = when {
        h in 7f..17f -> 0f
        h in 17f..20f -> (h - 17f) / 3f * 0.7f
        h >= 20f || h < 5f -> 0.7f
        else -> 0.7f * (1f - (h - 5f) / 2f)   // ۵ تا ۷ صبح
    }

    // =====================================================================
    //  رسم
    // =====================================================================
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        btnInteract[0] = w - 80f * d; btnInteract[1] = h - 90f * d
        btnRun[0] = w - 190f * d; btnRun[1] = h - 60f * d
        btnPause[0] = w - 40f * d; btnPause[1] = 40f * d
        vignette = Paint().apply {
            shader = RadialGradient(
                w / 2f, h / 2f, max(w, h) * 0.75f,
                intArrayOf(Color.TRANSPARENT, Color.argb(150, 0, 0, 0)),
                floatArrayOf(0.55f, 1f), Shader.TileMode.CLAMP
            )
        }
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val q = Prefs.quality(context)
        val hour = hourOfDay()
        val dark = darkness(hour)

        val camX = (px - w / 2f).coerceIn(0f, max(0f, WW - w))
        val camY = (py - h / 2f).coerceIn(0f, max(0f, WH - h))
        view.set(camX, camY, camX + w, camY + h)

        canvas.drawColor(c("#B8A27A"))
        canvas.save()
        canvas.translate(-camX, -camY)

        drawRoads(canvas, q)
        drawBuildings(canvas, q, dark)
        drawProps(canvas)
        drawCars(canvas, q)
        drawNpcs(canvas)
        drawPlayer(canvas)
        canvas.restore()

        // نورپردازی روز و شب
        if (dark > 0f) {
            p.style = Paint.Style.FILL
            p.color = Color.argb((dark * 255).toInt(), 8, 14, 38)
            canvas.drawRect(0f, 0f, w, h, p)
        } else if (q >= 1 && hour in 16.5f..17f) {
            p.color = Color.argb(35, 255, 140, 50)
            canvas.drawRect(0f, 0f, w, h, p)
        }
        if (q >= 1 && hour in 17f..19.5f) {
            p.color = Color.argb(30, 255, 120, 40)
            canvas.drawRect(0f, 0f, w, h, p)
        }
        if (q >= 1 && Prefs.rain(context)) drawRain(canvas, q, w, h)
        if (q >= 2) vignette?.let { canvas.drawRect(0f, 0f, w, h, it) }

        drawHud(canvas, w, h, hour)
        if (dlg != null) drawDialogue(canvas, w, h)
        if (paused) drawPause(canvas, w, h)
    }

    private fun drawRoads(cv: Canvas, q: Int) {
        // پیاده‌رو
        p.style = Paint.Style.FILL
        p.color = c("#9A9486")
        cv.drawRect(0f, 660f, WW, 940f, p)
        cv.drawRect(1060f, 0f, 1300f, WH, p)
        // آسفالت
        p.color = c("#3A3D40")
        cv.drawRect(0f, 700f, WW, 900f, p)
        cv.drawRect(1100f, 0f, 1260f, WH, p)
        // خط وسط
        p.color = c("#E8D9B0")
        var x = max(0f, view.left - (view.left % 90f))
        while (x < min(WW, view.right)) {
            if (x < 1090f || x > 1270f) cv.drawRect(x, 797f, x + 50f, 803f, p)
            x += 90f
        }
        var y = max(0f, view.top - (view.top % 90f))
        while (y < min(WH, view.bottom)) {
            if (y < 690f || y > 910f) cv.drawRect(1177f, y, 1183f, y + 50f, p)
            y += 90f
        }
        // خط‌کشی عابر پیاده
        p.color = Color.argb(200, 235, 235, 235)
        for (i in 0 until 8) cv.drawRect(1110f + i * 18f, 708f, 1122f + i * 18f, 740f, p)
        if (q >= 1) {
            p.color = Color.argb(40, 0, 0, 0)
            cv.drawRect(0f, 660f, WW, 666f, p)
            cv.drawRect(0f, 934f, WW, 940f, p)
        }
    }

    private fun drawBuildings(cv: Canvas, q: Int, dark: Float) {
        for (b in buildings) {
            if (!RectF.intersects(view, b.r)) continue
            val r = b.r
            if (q >= 1) {
                p.color = Color.argb(70, 0, 0, 0)
                cv.drawRect(r.left + 10f, r.top + 12f, r.right + 10f, r.bottom + 12f, p)
            }
            p.color = b.color
            cv.drawRect(r, p)
            // لبه‌ی بام
            p.color = Color.argb(60, 0, 0, 0)
            cv.drawRect(r.left, r.top, r.right, r.top + 10f, p)
            // پنجره‌ها
            if (q >= 1) {
                val cols = ((r.width() - 30f) / 56f).toInt()
                val rows = ((r.height() - 60f) / 70f).toInt()
                for (i in 0 until cols) for (j in 0 until rows) {
                    val wx = r.left + 24f + i * 56f
                    val wy = r.top + 30f + j * 70f
                    val lit = q >= 2 && dark > 0.3f && ((i * 7 + j * 3 + b.seed) % 3 != 0)
                    p.color = if (lit) c("#F6D87A") else c("#34495E")
                    cv.drawRect(wx, wy, wx + 22f, wy + 30f, p)
                }
            }
            // در
            p.color = c("#4A2F1C")
            when (b.kind) {
                2 -> cv.drawRect(r.centerX() - 80f, r.bottom - 46f, r.centerX() - 40f, r.bottom, p)
                1 -> {
                    val sy = if (b.sign == "داروخانه" || b.sign == "میوه‌فروشی") r.top else r.bottom - 60f
                    cv.drawRect(r.centerX() - 30f, if (sy == r.top) r.top else r.bottom - 50f,
                        r.centerX() + 30f, if (sy == r.top) r.top + 50f else r.bottom, p)
                }
            }
            // تابلوی مغازه
            if (b.sign != null) {
                val onTop = b.sign == "داروخانه" || b.sign == "میوه‌فروشی"
                val sy = if (onTop) r.top + 56f else r.bottom - 112f
                p.color = c("#1E2A33")
                cv.drawRoundRect(r.left + 20f, sy, r.right - 20f, sy + 40f, 8f, 8f, p)
                t.color = c("#F4E7B8"); t.textSize = 26f; t.textAlign = Paint.Align.CENTER
                cv.drawText(b.sign, r.centerX(), sy + 29f, t)
            }
            if (b.kind == 2) {
                t.color = Color.WHITE; t.textSize = 22f; t.textAlign = Paint.Align.CENTER
                cv.drawText("خانه", r.centerX(), r.top + 40f, t)
            }
        }
    }

    private fun drawProps(cv: Canvas) {
        // تابلوهای راهنما
        for (s in signs) {
            if (s.x < view.left - 150f || s.x > view.right + 150f) continue
            p.color = c("#2F4F3A")
            cv.drawRoundRect(s.x - 85f, s.y - 18f, s.x + 85f, s.y + 18f, 6f, 6f, p)
            t.color = Color.WHITE; t.textSize = 20f; t.textAlign = Paint.Align.CENTER
            cv.drawText(s.text, s.x, s.y + 7f, t)
        }
        // نخل (نماد اهواز)
        for (pm in palms) {
            if (pm[0] < view.left - 60f || pm[0] > view.right + 60f) continue
            p.color = Color.argb(60, 0, 0, 0)
            cv.drawCircle(pm[0] + 8f, pm[1] + 8f, 26f, p)
            p.color = c("#6B4A2B")
            cv.drawCircle(pm[0], pm[1], 7f, p)
            p.color = c("#3E7A3A")
            for (k in 0 until 6) {
                val a = k * 1.047f + 0.3f
                cv.drawCircle(pm[0] + kotlin.math.cos(a) * 15f, pm[1] + sin(a) * 15f, 10f, p)
            }
            p.color = c("#4F9448")
            cv.drawCircle(pm[0], pm[1], 11f, p)
        }
    }

    private fun drawCars(cv: Canvas, q: Int) {
        for (car in cars) {
            val cx = if (car.horizontal) car.pos else car.lane
            val cy = if (car.horizontal) car.lane else car.pos
            val hw = if (car.horizontal) 38f else 18f
            val hh = if (car.horizontal) 18f else 38f
            if (cx < view.left - 60f || cx > view.right + 60f || cy < view.top - 60f || cy > view.bottom + 60f) continue
            if (q >= 1) { p.color = Color.argb(70, 0, 0, 0); cv.drawRoundRect(cx - hw + 5f, cy - hh + 6f, cx + hw + 5f, cy + hh + 6f, 8f, 8f, p) }
            p.color = car.color
            cv.drawRoundRect(cx - hw, cy - hh, cx + hw, cy + hh, 8f, 8f, p)
            p.color = Color.argb(140, 20, 30, 40)
            if (car.horizontal) {
                val f = if (car.speed > 0) 1f else -1f
                cv.drawRect(cx + f * 6f - 12f, cy - hh + 4f, cx + f * 6f + 12f, cy + hh - 4f, p)
            } else {
                val f = if (car.speed > 0) 1f else -1f
                cv.drawRect(cx - hw + 4f, cy + f * 6f - 12f, cx + hw - 4f, cy + f * 6f + 12f, p)
            }
        }
    }

    private fun drawNpcs(cv: Canvas) {
        val target = targetNpc()
        for (n in npcs) {
            if (target === n) {
                val pulse = 34f + sin(anim * 4f) * 5f
                p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = c("#FFD54A")
                cv.drawCircle(n.x, n.y, pulse, p)
                p.style = Paint.Style.FILL
            }
            p.color = Color.argb(70, 0, 0, 0); cv.drawCircle(n.x + 3f, n.y + 4f, 15f, p)
            p.color = n.color; cv.drawCircle(n.x, n.y, 15f, p)
            p.color = c("#E3B98E"); cv.drawCircle(n.x, n.y - 6f, 8f, p)
            t.color = Color.WHITE; t.textSize = 18f; t.textAlign = Paint.Align.CENTER
            cv.drawText(n.name, n.x, n.y - 28f, t)
        }
    }

    private fun drawPlayer(cv: Canvas) {
        p.color = Color.argb(80, 0, 0, 0); cv.drawCircle(px + 3f, py + 5f, 15f, p)
        p.color = c("#2F6DB5"); cv.drawCircle(px, py, 15f, p)
        p.color = c("#E3B98E"); cv.drawCircle(px + fx * 4f, py + fy * 4f - 4f, 8f, p)
        p.color = c("#222222"); cv.drawCircle(px + fx * 4f, py + fy * 4f - 7f, 6f, p)
        t.color = Color.WHITE; t.textSize = 18f; t.textAlign = Paint.Align.CENTER
        cv.drawText("آرش", px, py - 28f, t)
        // علامت تعامل
        val n = nearestNpc()
        if (n != null && dlg == null) {
            t.color = c("#FFD54A"); t.textSize = 22f
            cv.drawText("گفتگو", n.x, n.y - 50f + sin(anim * 6f) * 3f, t)
        }
    }

    private fun drawRain(cv: Canvas, q: Int, w: Float, h: Float) {
        val count = if (q >= 2) rainX.size else rainX.size / 2
        p.color = Color.argb(110, 200, 215, 235)
        p.strokeWidth = 2f
        for (i in 0 until count) {
            if (!paused && dlg == null) {
                rainY[i] += 0.025f * (0.6f + (i % 5) * 0.15f)
                rainX[i] -= 0.004f
                if (rainY[i] > 1.1f) { rainY[i] = -0.1f; rainX[i] = Random.nextFloat() * 1.1f }
            }
            val x = rainX[i] * w
            val y = rainY[i] * h
            cv.drawLine(x, y, x - 6f, y + 18f, p)
        }
    }

    private fun circleBtn(cv: Canvas, b: FloatArray, label: String, on: Boolean = false) {
        p.style = Paint.Style.FILL
        p.color = Color.argb(if (on) 170 else 110, 30, 45, 60)
        cv.drawCircle(b[0], b[1], b[2], p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = Color.argb(180, 232, 217, 176)
        cv.drawCircle(b[0], b[1], b[2], p)
        p.style = Paint.Style.FILL
        t.color = Color.WHITE; t.textSize = b[2] * 0.5f; t.textAlign = Paint.Align.CENTER
        cv.drawText(label, b[0], b[1] + b[2] * 0.18f, t)
    }

    private fun drawHud(cv: Canvas, w: Float, h: Float, hour: Float) {
        // پنل مأموریت
        val pad = 12f * d
        p.style = Paint.Style.FILL
        p.color = Color.argb(150, 10, 16, 22)
        cv.drawRoundRect(pad, pad, pad + 300f * d, pad + 62f * d, 14f, 14f, p)
        val hh = hour.toInt()
        val mm = ((hour - hh) * 60f).toInt()
        t.color = c("#E8D9B0"); t.textSize = 16f * d; t.textAlign = Paint.Align.RIGHT
        cv.drawText("ساعت " + Ui.faStr(String.format(Locale.US, "%02d:%02d", hh, mm)), pad + 288f * d, pad + 22f * d, t)
        t.color = Color.WHITE; t.textSize = 13f * d
        cv.drawText(objective(), pad + 288f * d, pad + 46f * d, t)

        // دکمه‌ها
        circleBtn(cv, btnPause, "II")
        circleBtn(cv, btnInteract, "تعامل")
        circleBtn(cv, btnRun, "دویدن", running)

        // جوی‌استیک
        if (joyId != -1) {
            p.color = Color.argb(70, 255, 255, 255); cv.drawCircle(joyCx, joyCy, joyR, p)
            p.color = Color.argb(160, 232, 217, 176); cv.drawCircle(joyCx + joyDx, joyCy + joyDy, joyR * 0.45f, p)
        } else if (dlg == null && !paused) {
            p.color = Color.argb(35, 255, 255, 255)
            cv.drawCircle(110f * d, h - 100f * d, joyR, p)
            t.color = Color.argb(120, 255, 255, 255); t.textSize = 13f * d; t.textAlign = Paint.Align.CENTER
            cv.drawText("لمس کنید و بکشید", 110f * d, h - 96f * d, t)
        }

        // پیام کوتاه
        if (toastT > 0 && toast != null) {
            t.color = Color.WHITE; t.textSize = 16f * d; t.textAlign = Paint.Align.CENTER
            p.color = Color.argb(170, 10, 16, 22)
            cv.drawRoundRect(w / 2f - 160f * d, h * 0.2f, w / 2f + 160f * d, h * 0.2f + 40f * d, 12f, 12f, p)
            cv.drawText(toast!!, w / 2f, h * 0.2f + 26f * d, t)
        }
    }

    private fun drawDialogue(cv: Canvas, w: Float, h: Float) {
        val l = dlg ?: return
        val line = l[dIdx]
        val boxH = 150f * d
        val left = 16f * d
        val right = w - 16f * d
        val top = h - boxH - 12f * d
        p.style = Paint.Style.FILL
        p.color = Color.argb(225, 12, 18, 26)
        cv.drawRoundRect(left, top, right, top + boxH, 18f, 18f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = c("#E8D9B0")
        cv.drawRoundRect(left, top, right, top + boxH, 18f, 18f, p)
        p.style = Paint.Style.FILL

        t.color = c("#FFD54A"); t.textSize = 18f * d; t.textAlign = Paint.Align.RIGHT
        cv.drawText(line.who, right - 16f * d, top + 28f * d, t)

        val tw = (right - left - 32f * d).toInt()
        if (dLayout == null || dLayoutIdx != dIdx || dLayoutW != tw) {
            tp.textSize = 16f * d
            dLayout = StaticLayout.Builder.obtain(line.text, 0, line.text.length, tp, tw)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setLineSpacing(0f, 1.15f)
                .build()
            dLayoutIdx = dIdx; dLayoutW = tw
        }
        cv.save()
        cv.translate(left + 16f * d, top + 40f * d)
        dLayout?.draw(cv)
        cv.restore()

        t.color = Color.argb(180, 232, 217, 176); t.textSize = 12f * d; t.textAlign = Paint.Align.LEFT
        cv.drawText("برای ادامه لمس کنید ◂", left + 16f * d, top + boxH - 10f * d, t)
    }

    private fun drawPause(cv: Canvas, w: Float, h: Float) {
        p.style = Paint.Style.FILL
        p.color = Color.argb(190, 6, 10, 14)
        cv.drawRect(0f, 0f, w, h, p)
        t.color = c("#E8D9B0"); t.textSize = 34f * d; t.textAlign = Paint.Align.CENTER
        cv.drawText("توقف", w / 2f, h * 0.22f, t)
        val labels = arrayOf("ادامه", "ذخیره‌ی بازی", "خروج به منو")
        val bw = 280f * d; val bh = 50f * d
        for (i in 0 until 3) {
            val top = h * 0.3f + i * (bh + 14f * d)
            pauseBtns[i].set(w / 2f - bw / 2f, top, w / 2f + bw / 2f, top + bh)
            p.color = c("#2E4050")
            cv.drawRoundRect(pauseBtns[i], 14f, 14f, p)
            t.color = Color.WHITE; t.textSize = 18f * d
            cv.drawText(labels[i], w / 2f, top + bh * 0.64f, t)
        }
    }

    // =====================================================================
    //  ورودی لمسی و کیبورد
    // =====================================================================
    private fun hit(b: FloatArray, x: Float, y: Float) = hypot(x - b[0], y - b[1]) <= b[2] * 1.25f

    private fun onDown(id: Int, x: Float, y: Float) {
        if (paused) {
            when {
                pauseBtns[0].contains(x, y) -> paused = false
                pauseBtns[1].contains(x, y) -> { autoSave(); showToast("بازی ذخیره شد"); paused = false }
                pauseBtns[2].contains(x, y) -> { autoSave(); onExit() }
            }
            return
        }
        if (dlg != null) { advanceDialogue(); return }
        when {
            hit(btnPause, x, y) -> togglePause()
            hit(btnInteract, x, y) -> tryInteract()
            hit(btnRun, x, y) -> running = !running
            x < width * 0.5f && joyId == -1 -> {
                joyId = id; joyCx = x; joyCy = y; joyDx = 0f; joyDy = 0f
            }
        }
    }

    private fun onMove(id: Int, x: Float, y: Float) {
        if (id != joyId) return
        var dx = x - joyCx
        var dy = y - joyCy
        val l = hypot(dx, dy)
        if (l > joyR) { dx = dx / l * joyR; dy = dy / l * joyR }
        joyDx = dx; joyDy = dy
    }

    private fun onUp(id: Int) {
        if (id == joyId) { joyId = -1; joyDx = 0f; joyDy = 0f }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                onDown(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) onMove(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> onUp(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> { joyId = -1; joyDx = 0f; joyDy = 0f }
        }
        return true
    }

    private fun setKey(code: Int, down: Boolean): Boolean {
        when (code) {
            KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_DPAD_LEFT -> kL = down
            KeyEvent.KEYCODE_D, KeyEvent.KEYCODE_DPAD_RIGHT -> kR = down
            KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_DPAD_UP -> kU = down
            KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_DPAD_DOWN -> kD = down
            KeyEvent.KEYCODE_SHIFT_LEFT -> running = down
            else -> return false
        }
        return true
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_E || keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_SPACE) {
            if (paused) return true
            if (dlg != null) advanceDialogue() else tryInteract()
            return true
        }
        if (keyCode == KeyEvent.KEYCODE_ESCAPE) { togglePause(); return true }
        return setKey(keyCode, true) || super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean =
        setKey(keyCode, false) || super.onKeyUp(keyCode, event)

    // =====================================================================
    //  چرخه‌ی عمر
    // =====================================================================
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        requestFocus()
        last = System.nanoTime()
        handler.post(tick)
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(tick)
        super.onDetachedFromWindow()
    }
}
