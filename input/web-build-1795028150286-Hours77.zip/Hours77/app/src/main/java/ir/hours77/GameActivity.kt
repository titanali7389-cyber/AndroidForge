package ir.hours77

import android.app.Activity
import android.os.Bundle
import android.view.WindowManager

class GameActivity : Activity() {

    private lateinit var gameView: GameView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Ui.immersive(this)
        gameView = GameView(this, intent.getBooleanExtra("continue", false)) { finish() }
        setContentView(gameView)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) Ui.immersive(this)
    }

    override fun onPause() {
        super.onPause()
        gameView.autoPause()
    }

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onBackPressed() {
        gameView.togglePause()
    }
}
