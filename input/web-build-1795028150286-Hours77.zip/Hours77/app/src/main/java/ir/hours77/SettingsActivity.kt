package ir.hours77

import android.app.Activity
import android.os.Bundle

/** تنظیمات: نرخ فریم (۳۰/۶۰)، کیفیت گرافیک، باران */
class SettingsActivity : Activity() {

    private val qualityNames = arrayOf("کم", "متوسط", "بالا")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.immersive(this)
        build()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) Ui.immersive(this)
    }

    private fun build() {
        val col = Ui.column(this)
        col.addView(Ui.title(this, "تنظیمات", 36f))

        col.addView(Ui.button(this, "نرخ فریم: ${Ui.fa(Prefs.fps(this))}") {
            Prefs.setFps(this, if (Prefs.fps(this) == 30) 60 else 30)
            build()
        })
        col.addView(Ui.button(this, "کیفیت گرافیک: ${qualityNames[Prefs.quality(this)]}") {
            Prefs.setQuality(this, (Prefs.quality(this) + 1) % 3)
            build()
        })
        col.addView(Ui.button(this, "باران: ${if (Prefs.rain(this)) "روشن" else "خاموش"}") {
            Prefs.setRain(this, !Prefs.rain(this))
            build()
        })
        col.addView(Ui.label(this, "کیفیت «کم» جزئیات و جلوه‌های بصری را کم می‌کند؛ برای گوشی‌های ضعیف مناسب است.", 13f, "#6F7F8B"))
        col.addView(Ui.button(this, "بازگشت") { finish() })

        setContentView(Ui.scroll(this, col))
    }
}
