package ir.hours77

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** منوی اصلی: ادامه، بازی جدید، تنظیمات، خروج */
class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.immersive(this)
    }

    override fun onResume() {
        super.onResume()
        buildUi()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) Ui.immersive(this)
    }

    private fun buildUi() {
        val col = Ui.column(this)
        col.addView(Ui.title(this, "۷۷ ساعت", 48f))
        col.addView(Ui.label(this, "نمونه‌ی اولیه — محله‌ی گلستان، اهواز", 16f))
        col.addView(Ui.label(this, "داستان و شخصیت‌ها کاملاً تخیلی‌اند", 13f, "#6F7F8B"))

        col.addView(Ui.button(this, "ادامه", Prefs.hasSave(this)) {
            startActivity(Intent(this, GameActivity::class.java).putExtra("continue", true))
        })
        col.addView(Ui.button(this, "بازی جدید") {
            Prefs.clearSave(this)
            startActivity(Intent(this, GameActivity::class.java).putExtra("continue", false))
        })
        col.addView(Ui.button(this, "تنظیمات") {
            startActivity(Intent(this, SettingsActivity::class.java))
        })
        col.addView(Ui.button(this, "خروج") { finish() })

        setContentView(Ui.scroll(this, col))
    }
}
