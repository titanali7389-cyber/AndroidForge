package ir.hours77

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** ابزارهای ساخت رابط کاربری فارسی (بدون XML و بدون کتابخانه‌ی اضافی) */
object Ui {
    private val faDigits = charArrayOf('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')

    fun faStr(s: String): String =
        s.map { if (it in '0'..'9') faDigits[it - '0'] else it }.joinToString("")

    fun fa(n: Int): String = faStr(n.toString())

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun column(ctx: Context): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setBackgroundColor(Color.parseColor("#10161C"))
        setPadding(dp(ctx, 24), dp(ctx, 16), dp(ctx, 24), dp(ctx, 16))
    }

    fun scroll(ctx: Context, content: View): ScrollView = ScrollView(ctx).apply {
        isFillViewport = true
        setBackgroundColor(Color.parseColor("#10161C"))
        addView(content)
    }

    fun title(ctx: Context, text: String, sp: Float): TextView = TextView(ctx).apply {
        this.text = text
        textSize = sp
        setTextColor(Color.parseColor("#E8D9B0"))
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
    }

    fun label(ctx: Context, text: String, sp: Float, color: String = "#9FB0BC"): TextView =
        TextView(ctx).apply {
            this.text = text
            textSize = sp
            setTextColor(Color.parseColor(color))
            gravity = Gravity.CENTER
            setPadding(0, dp(ctx, 6), 0, 0)
        }

    fun button(ctx: Context, text: String, enabled: Boolean = true, onClick: () -> Unit): Button =
        Button(ctx).apply {
            this.text = text
            textSize = 18f
            isAllCaps = false
            setTextColor(if (enabled) Color.WHITE else Color.parseColor("#6B7780"))
            background = GradientDrawable().apply {
                cornerRadius = dp(ctx, 12).toFloat()
                setColor(Color.parseColor(if (enabled) "#2E4050" else "#1B242C"))
            }
            isEnabled = enabled
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(dp(ctx, 280), dp(ctx, 50)).apply {
                topMargin = dp(ctx, 10)
            }
        }

    @Suppress("DEPRECATION")
    fun immersive(a: Activity) {
        a.window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = a.window.attributes
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            a.window.attributes = lp
        }
    }
}
