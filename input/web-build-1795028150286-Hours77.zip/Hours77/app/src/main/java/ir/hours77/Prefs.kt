package ir.hours77

import android.content.Context

data class SaveData(
    val stage: Int,
    val hasMeds: Boolean,
    val x: Float,
    val y: Float,
    val minutes: Float
)

/** تنظیمات و ذخیره‌ی بازی (SharedPreferences) */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("hours77", Context.MODE_PRIVATE)

    fun fps(c: Context): Int = sp(c).getInt("fps", 30)
    fun setFps(c: Context, v: Int) { sp(c).edit().putInt("fps", v).apply() }

    /** 0 = کم، 1 = متوسط، 2 = بالا */
    fun quality(c: Context): Int = sp(c).getInt("quality", 1)
    fun setQuality(c: Context, v: Int) { sp(c).edit().putInt("quality", v).apply() }

    fun rain(c: Context): Boolean = sp(c).getBoolean("rain", true)
    fun setRain(c: Context, v: Boolean) { sp(c).edit().putBoolean("rain", v).apply() }

    fun hasSave(c: Context): Boolean = sp(c).getBoolean("save_exists", false)

    fun save(c: Context, d: SaveData) {
        sp(c).edit()
            .putBoolean("save_exists", true)
            .putInt("s_stage", d.stage)
            .putBoolean("s_meds", d.hasMeds)
            .putFloat("s_x", d.x)
            .putFloat("s_y", d.y)
            .putFloat("s_min", d.minutes)
            .apply()
    }

    fun load(c: Context): SaveData? {
        val s = sp(c)
        if (!s.getBoolean("save_exists", false)) return null
        return SaveData(
            s.getInt("s_stage", 0),
            s.getBoolean("s_meds", false),
            s.getFloat("s_x", 1200f),
            s.getFloat("s_y", 880f),
            s.getFloat("s_min", 0f)
        )
    }

    fun clearSave(c: Context) { sp(c).edit().putBoolean("save_exists", false).apply() }
}
