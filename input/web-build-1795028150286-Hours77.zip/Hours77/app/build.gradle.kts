plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ir.hours77"
    compileSdk = 34

    defaultConfig {
        applicationId = "ir.hours77.game"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0-prototype"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // برای نصب راحت نسخه‌ی release با کلید debug امضا می‌شود (فقط برای نمونه‌ی اولیه)
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
